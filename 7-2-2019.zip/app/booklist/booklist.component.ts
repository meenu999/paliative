import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'app-booklist',
  templateUrl: './booklist.component.html',
  styleUrls: ['./booklist.component.css']
})
export class BooklistComponent implements OnInit {
  public BookDetails:any=[{title:"BOOK 1",author:"author 1",publisher:"publisher 1"},{title:"BOOK 2",author:"author 2",publisher:"publisher 2"},{title:"BOOK 3",author:"author 3",publisher:"publisher 3"},{title:"BOOK 4",author:"author 4",publisher:"publisher 4"}];
 sellbook:any;
  addbook(data:any){
 this.sellbook=data;
}
  constructor() { }

  ngOnInit() {
  }

}
