import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-studentlist',
  templateUrl: './studentlist.component.html',
  styleUrls: ['./studentlist.component.css']
})
export class StudentlistComponent implements OnInit {
public StudentDetails:any=[{rollno:"xxx17",name:"Anu",batch:"MCALE",department:"CS"},
{rollno:"xxx18",name:"MEENU THOMAS",batch:"MCALE",department:"CS"},{rollno:"xxx19",name:"AMMU JACOB",batch:"MCALE",department:"CS"}]
sellstudent:any;
addstudent(data:any){
this.sellstudent=data;
}
  constructor() { }

  ngOnInit() {
  }

}
