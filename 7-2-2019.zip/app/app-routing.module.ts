import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
// import { BooklistComponent } from './booklist/booklist.component';
// import { BookComponent } from './book/book.component';
import { StudentlistComponent } from './studentlist/studentlist.component';
import { StudentComponent } from './student/student.component';


const routes: Routes = [{path:"studentlist",component:StudentlistComponent}
,{path:"student",component:StudentComponent}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
