<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Register extends Model
{
    //
	public $fillable = ['id','pname','address','district','city','gender','phone','dob','email','password','cpassword','name','relationship','address2','photo','role','status'];
	
}