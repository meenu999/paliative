<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Leave extends Model
{
    public $fillable = ['dname','date','reason','time','status'];
}
