<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class treatment extends Model
{
    public $fillable = ['dname','pname','age','date','disease','food','medicine','status'];
	
}
