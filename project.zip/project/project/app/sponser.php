<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class sponser extends Model
{
    public $fillable = ['spid','sname','email','saddress','sdistrict','scity','sgender','sphone','password','cpassword','role','status'];
}
