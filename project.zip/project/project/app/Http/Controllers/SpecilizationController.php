<?php

namespace App\Http\Controllers;

use App\specilization;
use Illuminate\Http\Request;
use DB;

class SpecilizationController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        
    $specilization = Specilization::with('specilization')->get();
    return view('searchresult', compact('specilization'));
    }
     public function insert(Request $request)
     {
         $specilization=$request->input('specilization');
         DB::insert("insert into specilizations(specilization,status)values(?,?)",[$specilization,1]);
         return view("addspecilization"); 
     }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\specilization  $specilization
     * @return \Illuminate\Http\Response
     */
    public function show(specilization $specilization)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\specilization  $specilization
     * @return \Illuminate\Http\Response
     */
    public function edit(specilization $specilization)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\specilization  $specilization
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, specilization $specilization)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\specilization  $specilization
     * @return \Illuminate\Http\Response
     */
    public function destroy(specilization $specilization)
    {
        //
    }
}
