<?php

namespace App\Http\Controllers;

use App\payment;
use Illuminate\Http\Request;
use DB;


class PaymentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $unm=$request->input('email');    
        $check=DB::table('sponsers')->where(['email'=>$unm])->get();    
        if(count($check)==0)
         {
           $users=new payment([
               'semail'=>$request->get('semail'),
               'sname'=>$request->get('sname'),
               'amount'=>$request->get('amount'),
               'cardno'=>$request->get('cardno'),
               'cvv'=>$request->get('cvv'),
               'expdate'=>$request->get('expdate'),
               'status'=>3
            ]);
            $users->save();
            $sname=$request->input('amount');
           }
     }   
    
    
    public function insert(Request $request)
     {   
         //return $request;
         //$semail=$request->input('semail');
         $sname=$request->input('sname');
         $amount=$request->input('amount');
         $cardno=$request->input('cardno');
         $cvv=$request->input('cvv');
         $expdate=$request->input('expdate');
         DB::insert("insert into payments(sname,amount,cardno,cvv,expdate,status)values(?,?,?,?,?,?)",[$sname,$amount,$cardno,$cvv,$expdate,1]);
         $request->session()->put('sname',$sname);
         return view('print'); 
         //return view("print"); 
        
     }

    /**
     * Display the specified resource.
     *
     * @param  \App\payment  $payment
     * @return \Illuminate\Http\Response
     */
    public function show(payment $payment)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\payment  $payment
     * @return \Illuminate\Http\Response
     */
    public function edit(payment $payment)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\payment  $payment
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, payment $payment)
    {
       
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\payment  $payment
     * @return \Illuminate\Http\Response
     */
    public function destroy(payment $payment)
    {
        //
    }
}
