<?php

namespace App\Http\Controllers;

use App\Adddoctor;
use Illuminate\Http\Request;
use DB;

class AdddoctorController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        {
            $adddoctor = Adddoctor::all();
            return view ('viewdoctor',compact('adddoctor'));
        }
        
        //return view('viewdoctor');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
    
        //
        $unm=$request->input('username');
        //$msg="";
        $filename6=$request->img->getClientOriginalName();
        $request->img->storeAs('public/upload',$filename6);
        //echo $filename6;
		 $check=DB::table('registers')->where(['email'=>$unm])->get();
         if(count($check)==0)
         {
            $users=new Adddoctor([
               'dname'=>$request->get('dname'),
               'sid'=>$request->get('specilization'),
               'address'=>$request->get('address'),
               'country'=>$request->get('country'),
               'state'=>$request->get('state'),
               'city'=>$request->get('city'),
               'email'=>$request->get('email'),
               'gender'=>$request->get('gender'),
               'phone'=>$request->get('phone'),
               'photo'=>$filename6,
              
               //'username'=>$request->get('username'),
               //'password'=>$request->get('password'),
               'role'=>2,
               'status'=>2
            ]);
            $users->save();
            $unm=$request->input('email');
            $pwd=$request->input('password');
            //$conpwd=$request->input('conpassword');
           
           // if ($pwd==$conpwd)
           //{             
               $result=DB::insert("insert into logins(email,password,role,status,remember_token)values(?,?,?,?,?)",[$unm,$pwd,2,2,'null']);
               $adddoctor = Adddoctor::all();
               return view ('viewdoctor',compact('adddoctor'));
               return view("viewdoctor");
               //echo "sucess";
           //}  
           //else
           //{
              //$msg= "not match";
               //return view('welcome');
           //}	
               
}	
else
{
           //    $msg= "User Already Registered";
               
              return redirect('/already');
}	
   //return view('/add_student');					 
}
    

public function profile(Request $request ,$username){ 
    $request->session()->put('email',$username); 
    return view('profile');
 }

 

    /**
     * Display the specified resource.
     *
     * @param  \App\Adddoctor  $adddoctor
     * @return \Illuminate\Http\Response
     */
    public function show(Adddoctor $adddoctor)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Adddoctor  $adddoctor
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request ,Adddoctor $adddoctor,$id)
    {
        
            $request->session()->put('id',$id);
            //$edt= $request->session()->get('username');
            $edit = DB::table('adddoctors')->where(['id',$id]);
            return view('editdoctorprofile',compact($edit));
            
        
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Adddoctor  $adddoctor
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Adddoctor $adddoctor)
    {
        
        $d_id=$request->input('id');
        $dname=$request->input('dname');
		$address=$request->input('address');
		$country=$request->input('country');
		$city=$request->input('city');
		$state=$request->input('state');
        $phone=$request->input('phone');
        $experience=$request->input('experience');
        $proof=$request->input('proof');
		DB::table('adddoctors')->where('id',$d_id)->update(['dname'=>$dname,
		'address'=>$address,'country'=>$country,'city'=>$city,'state'=>$state,
        'phone'=>$phone,'experience'=>$experience,'proof'=>$proof]);
         return redirect('profile');   
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Adddoctor  $adddoctor
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        DB::delete('delete from adddoctors where id=?',[$id]);
        return redirect("viewdoctor");
        //DB::delete('update adddoctors set status=0 where id = ?',[$id]);
		//return redirect("ViewDoctor");
    }
    public function search(Request $request)
    {
        return $request;
      $sid=$request->get('specilization');
     // dd($sid);
      $specilization=adddoctor::where('sid','=',$sid)->get();
      //dd($specilization);
      return view("searchresult");
	  
	     }
}
