<?php

namespace App\Http\Controllers;

use App\treatment;
use Illuminate\Http\Request;
use DB;

class TreatmentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        return $request;
         //$semail=$request->input('semail');
         $dname=$request->input('dname');
         $pname=$request->input('pname');
         $age=$request->input('age');
         $date= date('Y-m-d');
         $disease=$request->input('disease');
         $food=$request->input('food');
         $medicine=$request->input('medicine');
         $status=$request->input('status');
         
         DB::insert("insert into treatment(dname,pname,age,date,disease,food,medicine,status)values(?,?,?,?,?,?,?,?)",[$dname,$pname,$age,$date,$disease,$food,$medicine,2]);
         //$request->session()->put('pname',$pname);
         return view('addtreatment'); 
         
         
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\treatment  $treatment
     * @return \Illuminate\Http\Response
     */
    public function show(treatment $r)
    {
        $pname = $r->pname;
        return view('addtreatment')->with('pname', $pname);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\treatment  $treatment
     * @return \Illuminate\Http\Response
     */
    public function edit(treatment $treatment)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\treatment  $treatment
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, treatment $treatment)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\treatment  $treatment
     * @return \Illuminate\Http\Response
     */
    public function destroy(treatment $treatment)
    {
        //
    }
}
