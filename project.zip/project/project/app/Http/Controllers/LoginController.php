<?php

namespace App\Http\Controllers;

use App\login;
use Illuminate\Http\Request;
use DB;


class LoginController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('login');
    }


    public function login(Request $request)
    {
        $username=$request->input('email');
		$password=$request->input('password');
		$checkLogin1=DB::table('logins')->where(['email'=>$username,'password'=>$password,'role'=>0,'status'=>0])->get();
		$checkLogin2=DB::table('logins')->where(['email'=>$username,'password'=>$password,'role'=>1,'status'=>1])->get();
        $checkLogin3=DB::table('logins')->where(['email'=>$username,'password'=>$password,'role'=>2,'status'=>2])->get();
        $checkLogin4=DB::table('logins')->where(['email'=>$username,'password'=>$password,'role'=>3,'status'=>3])->get();
		if(count($checkLogin1) >0)
		{
            session_start();
			$request->session()->put('email', $username);
			
			return view('adminhome');
		}
		else if(count($checkLogin2)>0)
		{
            session_start(); 
            $request->session()->put('email', $username);
            return view('patienthome');
			//echo "good";
		}
		else if(count($checkLogin3)>0)
		{
            session_start();
            $request->session()->put('email', $username);
            return view('doctorhome');
			//echo "very good";
        }
        else if(count($checkLogin4)>0)
		{
            session_start();
            $request->session()->put('email', $username);
            return view('sponserhome');
			//echo "very good";
        }
        else
        {
			echo "failed";
		}
    
    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Login  $login
     * @return \Illuminate\Http\Response
     */
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\login  $login
     * @return \Illuminate\Http\Response
     */
    public function show(login $login)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\login  $login
     * @return \Illuminate\Http\Response
     */
    public function edit(login $login)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\login  $login
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, login $login)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\login  $login
     * @return \Illuminate\Http\Response
     */
    public function destroy(login $login)
    {

        //
    }
    public function logout(Request $request) {
        session_start();
        session_destroy();
        session()->flush();
        return redirect('/Login');
    }
}
