<?php

namespace App\Http\Controllers;

use App\appointments;
use App\adddoctors;
use App\registers;
use App\specilizations;
use Illuminate\Http\Request;
use DB;

class AppointmentsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        {
            $appointments = Appointments::all();
            return view ('viewappointments',compact('appointments'));
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function appointment(Request $request)
    {   
        //return $request;
        $pname=$request->input('pname');
        $dname=$request->input('dname');
        //dd($dname);
        $date=$request->input('date');
        $time=$request->input('time');
        $dname=DB::table('adddoctors')->select('dname')->where('dname',$dname)->pluck('dname');
        $leaves=DB::table('leaves')->where(['dname'=>$dname])->where(['date'=>$date])->where(['time'=>$time])->where(['status'=>'approved'])->get();
        $leave=count($leaves);
        //dd($leave);
       
        $appointments=DB::table('appointments')->where(['dname'=>$dname])->where(['date'=>$date])-> where(['time'=>$time])->where(['status'=>1])->get();
        $app=count($appointments);
        //$request->session()->put('dname',$dname);
        //dd($app);
        if(($leave==0)&&($app==0))
	   {
		   
		  
		$result=DB::insert("insert into appointments(pname,dname,date,time,status)values(?,?,?,?,?)",[$pname,$dname,$date,$time,'1']);
    
        return view("sucess");


		   
	   }
	   else
	   {
		   return view("fail");

		    
	   }
		    
	   
    

       
      // DB::insert("insert into appointments(rid,dname,date,time,status)values(?,?,?,?,?)",[$rid,$did,$date,4,1]);
       
       
       
    }
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\appointments  $appointments
     * @return \Illuminate\Http\Response
     */
    public function show(appointments $appointments)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\appointments  $appointments
     * @return \Illuminate\Http\Response
     */
    public function edit(appointments $appointments)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\appointments  $appointments
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, appointments $appointments)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\appointments  $appointments
     * @return \Illuminate\Http\Response
     */
    public function destroy(appointments $appointments)
    {
        //
    }
}
