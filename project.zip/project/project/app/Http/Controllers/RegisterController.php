<?php

namespace App\Http\Controllers;

use App\Register;
use Illuminate\Http\Request;
use DB;


class RegisterController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
		
    {
	  
	  //echo $unm;
	  //$check=DB::table('logins')->where(['username'=>$unm,'password'=>$pwd])->get();
	  //if(count($check)>0)
	  //{
       // echo " sucess";
		  //return view('welcome');
      //}
	//else
	//{
		//echo "no sucess";
	//}
	
    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Login  $login
     * @return \Illuminate\Http\Response
     */
	}
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $unm=$request->input('email');
		//$msg="";
		 $check=DB::table('registers')->where(['email'=>$unm])->get();
         if(count($check)==0)
         {
            $users=new Register([
               'pname'=>$request->get('pname'),
               'address'=>$request->get('address'),
               'district'=>$request->get('district'),
               
               'gender'=>$request->get('gender'),
               'phone'=>$request->get('phone'),
               'dob'=>$request->get('dob'),
               'email'=>$request->get('email'),
               //'password'=>$request->get('password'),
               'role'=>1,
               'status'=>1
            ]);
            $users->save();
            $unm=$request->input('email');
            $pwd=$request->input('password');

            //$conpwd=$request->input('conpassword');
           
           // if ($pwd==$conpwd)
           //{             
               $result=DB::insert("insert into logins(email,password,role,status,remember_token)values(?,?,?,?,?)",[$unm,$pwd,1,1,'null']);
               return view("login");
           //}  
           //else
           //{
              //$msg= "not match";
               //return view('welcome');
           //}	
               
}	
else
{
           //    $msg= "User Already Registered";
               
              return redirect('/already');
}	
   //return view('/add_student');					 
}
    


    /**
     * Display the specified resource.
     *
     * @param  \App\Register  $register
     * @return \Illuminate\Http\Response
     */
    public function show(Register $register)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Register  $register
     * @return \Illuminate\Http\Response
     */
    public function profile(Request $request ,$username){ 
        $request->session()->put('email',$username); 
        return view('patientprofile');
     }
    public function edit(Request $request,Register $register,$email)
    {
        $request->session()->put('email',$email);
            //$edt= $request->session()->get('username');
            $edit = DB::table('registers')->where(['email',$email]);
            return view('updatepatientProfile',compact($edit));
            
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Register  $register
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request,Register $register)
    {
        
        //$filename = $request->photo->getClientOriginalName();
        //$request->photo->storeAs('public/upload',$filename);
        
         //dd ($filename);
        $p_email=$request->input('email');
        $pname=$request->input('pname');
		$address=$request->input('address');
		
		$gender=$request->input('gender');
        $dob=$request->input('dob');
        $phone=$request->input('phone');
        $name=$request->input('name');
        $relationship=$request->input('relationship');
        $address2=$request->input('address2');

		DB::table('registers')->where('email',$p_email)->update([
		'address'=>$address,'gender'=>$gender,
        'phone'=>$phone,'name'=>$name, 'relationship'=>$relationship,'address2'=>$address2,
        ]);
         return view('updatepatientProfile');    
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Register  $register
     * @return \Illuminate\Http\Response
     */
    public function destroy(Register $register)
    {
        //
    }
}
