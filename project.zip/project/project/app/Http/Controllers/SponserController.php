<?php

namespace App\Http\Controllers;

use App\sponser;
use Illuminate\Http\Request;
use DB;

class SponserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
         //
        $unm=$request->input('email');
		//$msg="";
		 $check=DB::table('sponsers')->where(['email'=>$unm])->get();
         if(count($check)==0)
         {
             //return request;
            $users=new sponser([
               'sname'=>$request->get('sname'),
               'saddress'=>$request->get('saddress'),
               'sdistrict'=>$request->get('sdistrict'),
               'scity'=>$request->get('scity'),
               'sgender'=>$request->get('sgender'),
               'sphone'=>$request->get('sphone'),
               'email'=>$request->get('email'),
              // 'password'=>$request->get('password'),
               'role'=>3,
               'status'=>3
            ]);
            $users->save();
            $unm=$request->input('email');
            $pwd=$request->input('password');

            //$conpwd=$request->input('conpassword');
           
           // if ($pwd==$conpwd)
           //{             
               $result=DB::insert("insert into logins(email,password,role,status,remember_token)values(?,?,?,?,?)",[$unm,$pwd,3,3,'null']);
               return view("login");
           //}  
           //else
           //{
              //$msg= "not match";
               //return view('welcome');
           //}	
               
}	
else
{
           //    $msg= "User Already Registered";
               
              return redirect('/already');
}	
   //return view('/add_student');					 
}
    


    /**
     * Display the specified resource.
     *
     * @param  \App\sponser  $sponser
     * @return \Illuminate\Http\Response
     */
    public function show(sponser $sponser)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\sponser  $sponser
     * @return \Illuminate\Http\Response
     */
    public function edit(sponser $sponser)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\sponser  $sponser
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, sponser $sponser)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\sponser  $sponser
     * @return \Illuminate\Http\Response
     */
    public function destroy(sponser $sponser)
    {
        //
    }
}
