<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\district;
use App\city;
use DB;

class DistrictController extends Controller
{
    public function index()
	{
	$district=DB::table('tbl_district')->get();
	return view('index',['data'=>$district]);
	}
	public function cityajax(Request $request)
	{
		$id = $_POST['did'];
		$city= city::where("district_id",$id)->get();
		return $city;
	}
	
	
}	
