<?php

namespace App\Http\Controllers;

use App\addtreatment;
use Illuminate\Http\Request;

class AddtreatmentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $pname=$request->input('pname');
        //  dd($amount);
        // DB::insert("insert into amounts(amount,status)values(?,?)",[$amount,1]);
         return view('addtreatment',compact('pname')); 
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\addtreatment  $addtreatment
     * @return \Illuminate\Http\Response
     */
    public function show(addtreatment $addtreatment)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\addtreatment  $addtreatment
     * @return \Illuminate\Http\Response
     */
    public function edit(addtreatment $addtreatment)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\addtreatment  $addtreatment
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, addtreatment $addtreatment)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\addtreatment  $addtreatment
     * @return \Illuminate\Http\Response
     */
    public function destroy(addtreatment $addtreatment)
    {
        //
    }
}
