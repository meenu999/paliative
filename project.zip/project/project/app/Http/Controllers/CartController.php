<?php

namespace App\Http\Controllers;

use App\cart;
use Illuminate\Http\Request;
use DB;
use Session;

class CartController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }
	public function addcart(Request $request)
	{
		 $pid=$request->input('pid');
		 //dd ($pid);
		if(session()->has('email'))
		{
			echo $email=Session::get('email');
	$id=DB::table('registers')->select('id')->where('email',"=",$email)->get();
				
				
		}
			else 
		{
echo "login First";
			
		}
		
		foreach($id as $login)
		{
		$loginid=$login->id;
		
 $shoppingcartz=DB::table('carts')->select('pid')->where('id',"=",$loginid)->get();
foreach($shoppingcartz as $shoppy)
{
	if($shoppy->pid==$pid)
	{
		$cartz=DB::table('carts')->where('id',"=",$loginid)->get();

		 Return view('cart',compact('cartz')); 
	}
}
		 $status=1;
		 $count=1;
		
	 $carts=array('id'=>$loginid,'pid'=>$pid,'count'=>$count,'status'=>$status);
		DB::table('carts')->insert($carts);	
		$cartz=DB::table('carts')->select('pid')->where('id',"=",$loginid)->where('status',"=",1)->get();

		 Return view('cart',compact('cartz'));    

		}		
		
		}
				
		
				
		
	

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        
 
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\cart  $cart
     * @return \Illuminate\Http\Response
     */
    public function show(cart $cart)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\cart  $cart
     * @return \Illuminate\Http\Response
     */
    public function edit(cart $cart)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\cart  $cart
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, cart $cart)
    {
        //DB::delete('update carts set status="Delivered" where cartid = ?',[$id]);
		//return redirect("");
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\cart  $cart
     * @return \Illuminate\Http\Response
     */
    public function destroy( $pid)
    {
        DB::delete('delete from carts where pid=?',[$pid]);
        return view("viewcart");
    }
}
