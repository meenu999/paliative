<?php

namespace App\Http\Controllers;

use App\Leave;
use Illuminate\Http\Request;
use DB;

class LeaveController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        {
            $leave = Leave::all();
            return view ('viewleave',compact('leave'));
        }
    }
    
    
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $unm=$request->input('email');    
        $check=DB::table('adddoctors')->where(['email'=>$unm])->get();    
        if(count($check)==0)
         {
            $users=new Leave([
               'date'=>$request->get('date'),
                'time'=>$request->get('time'),
               'reason'=>$request->get('reason'),
               'status'=>'Not Approved'
            ]);
            $users->save();
            $dname=$request->input('dname');
            $pname=$request->input('pname');
        }   
    
    }
    public function insert(Request $request)
     {
         $date=$request->input('date');
         $time=$request->input('time');
         $reason=$request->input('reason');
         $dname=$request->input('dname');
         DB::insert("insert into leaves(dname,date,time,reason,status)values(?,?,?,?,?)",[$dname,$date,$time,$reason,'Not Approved']);
         $request->session()->put('dname',$dname);
         
         return view("viewdoctorleave"); 
     }

    /**
     * Display the specified resource.
     *
     * @param  \App\Leave  $leave
     * @return \Illuminate\Http\Response
     */
    public function show(Leave $leave)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Leave  $leave
     * @return \Illuminate\Http\Response
     */
    public function edit(Leave $leave)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Leave  $leave
     * @return \Illuminate\Http\Response
     */
    public function update($id)
    {
        DB::delete('update leaves set status="Approved" where leave_id = ?',[$id]);
		return redirect("viewleave");
      
    }
    



    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Leave  $leave
     * @return \Illuminate\Http\Response
     */
    public function destroy(Leave $leave)
    {
        DB::delete('update leaves set status="Not Approved" where leave_id = ?',[$id]);
        return redirect("viewleave");
    }    
        
}
