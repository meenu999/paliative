<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class cart extends Model
{
    public $fillable = ['cartid','pid','id','count','status'];
}
