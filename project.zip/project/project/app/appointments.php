<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class appointments extends Model
{
    public $fillable=['aid','pname','dname','date','time','status'];
}
