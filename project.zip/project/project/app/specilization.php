<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class specilization extends Model
{
    public $fillable=['specilization','status'];
}
