<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class feedback extends Model
{
    public $fillable = ['pname','dname','message','status'];
}
