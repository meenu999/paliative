<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Login extends Model
{
    //
	public $fillable = ['username','password','name','role','status','remember_token'];
}
