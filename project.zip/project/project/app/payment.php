<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class payment extends Model
{
    public $fillable=['payid','semail','sname','cardno','cvv','amount','expdate','status'];
} 

