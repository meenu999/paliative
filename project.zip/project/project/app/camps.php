<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class camps extends Model
{
    public $fillable=['campid','campname','venue','date','time','status'];
}

