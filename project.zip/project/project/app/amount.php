<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class amount extends Model
{
    public $fillable = ['amountid','amount','status'];
}
