<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Adddoctor extends Model
{
    //
	public $fillable = ['dname','sid','address','country','state','city','email','gender','phone','photo','experience','proof','username','password','role','status'];
}
