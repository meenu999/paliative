<!DOCTYPE html>
<html>
<head>
<style>
table {
  width:100%;
}
table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
}
th, td {
  padding: 15px;
  text-align: left;
}
table#t01 tr:nth-child(even) {
  background-color: #eee;
}
table#t01 tr:nth-child(odd) {
 background-color: #fff;
}
table#t01 th {
  background-color: black;
  color: white;
}
</style>
</head>
<body>
<a href="javascript:window.print()"><img src="..\..\..\..\..\..\images\download1.jpg" height="40"></a>
<div>
<?php
						use App\Payment;
                        
                        $sess=session()->get('sname');
                       // dd($sess);
                        $a=Payment::where('sname',$sess)->get();
                        
                        foreach($a as $object) 
                        {
                            //$id=$object->id;
                            //$email=$object->email;
                           
                        }   
                       $users=DB::table('payments')->where('sname',$sess)->first();
                       
                        ?> 
                        <h1 align="center">Hospiec Charity Fund</h1>
                        <table id="t01">
                        <tr>
                       <th align="centre"> Name</th> 
                       <th align="centre">Card Number</th>
                       <th align="centre">Amount</th>
                       </tr> 
                        <tr>
                        <td> <?php echo $users->sname; ?></td>
                        <td><?php echo $users->cardno; ?></td>
                        <td><?php echo $users->amount; ?></td>
                        </tr>
                        </table>
                        </div>