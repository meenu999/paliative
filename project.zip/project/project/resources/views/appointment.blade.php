<!--A Design by W3layouts 
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!doctype html>
<html lang="en">
<head>
<title>Doctor Appointment </title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Doctor Appointment Form Widget Responsive, Login form web template,Flat Pricing tables,Flat Drop downs  Sign up Web Templates, Flat Web Templates, Login signup Responsive web template, Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- font files -->
<link href="//fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
<!-- /font files -->
<!-- css files -->
<link href="css/style5.css" rel='stylesheet' type='text/css' media="all" />
<!-- /css files -->
<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
<script src="js/jquery.vide.min.js"></script>

</head>
<body>
	<div data-vide-bg="video/patient">
		<div class="center-container">
			<h1 class="header-w3ls">Doctor Appointment Form</h1>
            <?php
			use App\Register;

                        $sess=session()->get('email');
                        //echo $sess;
						$a=Register::where('email',$sess)->get();
					    $sql=DB::select('SELECT * FROM registers');
                        foreach($sql as $object) 
                        {
                            $id=$object->id;
                            $email=$object->email;
                           
                        }   
                       $users=DB::table('registers')->where('email',$sess)->first();
                       
                        ?>
			<div class="content-top">
				<div class="content-w3ls">
					<div class="form-w3ls">
						<form action="/appointment" method="post">
                        <input type="hidden" name="_token" value="{{csrf_token()}}" />
                         <input type="hidden"  name="rid" value="<?php echo $users->id;?>">
						 @csrf
							<div class="content-wthree1">
								<div class="grid-agileits1">
									<div class="form-control"> 
										<label class="header">Patient Name <span>*</span></label>
										<input type="text" id="name" name="pname" placeholder="Name" title="Please enter your Full Name" required="" value="<?php echo $users->pname;?>" >
									</div>
									<div class="form-control">	
										<label class="header">Email <span>*</span></label>
										<input type="email" id="email" name="email" placeholder="Mail@example.com" title="Please enter a Valid Email Address" required="" value="<?php echo $users->email;?>">
									</div>
									<div class="form-control">	
										<label class="header">Phone Number <span>*</span></label>
										<input type="text" id="name" name="phone " placeholder="Phone Number" title="Please enter your Phone Number" required="" value="<?php echo $users->phone;?>">
									</div>
								</div>
							</div>
					</div>
					<div class="form-w3ls-1">
						
								<div class="form-control"> 
									<label class="header">Doctor Name <span>*</span></label>
									<input type="text" id="name" name="dname" placeholder="Name" title="Please enter Doctor Name" required="" autocomplete="off">
                                    
									<label class="header">Appointment Date <span>*</span></label>
									<!--<input type="text" id="name" class="form-control date" name="date" autocomplete="off"/>-->
									<input type="date" id="name" name="date" placeholder="Date"  class="form-control date" title="Select the Date" required="">
									<!--<input type="text" id="name" name="name" placeholder="Line" title="Please enter your Line" required="">
									<input type="text" id="name" name="name" placeholder="City" title="Please enter your City" required="">
									<input type="text" id="name" name="name" placeholder="Zip code" title="Please enter your Zip code" required="">-->
								</div>
								
							
					</div>
					<div class="clear"></div>
				</div>
				<div class="content-w3ls">
					<div class="form-w3ls">
							<div class="content-wthree2">
								<div class="grid-w3layouts1">
									<div class="w3-agile1">
										<label class="rating">Best time to Consult <span>*</span></label>
										<ul>
											<li>
												<input type="radio" id="a-option" name="time">
												<label for="a-option">FN </label>
												<div class="check"></div>
											</li>
											<li>
												<input type="radio" id="b-option" name="time">
												<label for="b-option">AN</label>
												<div class="check"><div class="inside"></div></div>
											</li>
											
										</ul>
									</div>	
								</div>
								</div>
								</div>
								
								<div class="wthreesubmitaits">
									<input type="submit" name="submit" value="Submit">
								</div>
								</div>
						</form>
							
					
					<!--<div class="form-w3ls-1">
						<div class="grid-w3layouts1">
							<div class="w3-agile1">
								<label class="rating">I would like to (choose one)<span>*</span></label>
									<ul>
										<li>
											<input type="radio" id="d-option" name="selector2">
											<label for="d-option">A new patient appointment</label>
											<div class="check"></div>
										</li>
										<li>
											<input type="radio" id="e-option" name="selector2">
											<label for="e-option">A routine checkup</label>
											<div class="check"><div class="inside"></div></div>
										</li>
										<li>
											<input type="radio" id="f-option" name="selector2">
											<label for="f-option">A comprehensive health exam </label>
											<div class="check"><div class="inside"></div></div>
										</li>
									</ul>
							</div>	
						</div>		
					</div>
					<div class="clear"></div>
				</div>-->
			</div>	
				
				
	</div>
	<script>
$('.date').datepicker({
    multidate: true
});

$('.date').datepicker('setDates' )
</script>

</body>
</html>
