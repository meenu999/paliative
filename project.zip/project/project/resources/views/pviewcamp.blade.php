<!doctype html>
<html lang="en">

<head>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="icon" href="img/favicon.png" type="image/png">
	<title>Hospice Medical</title>
    
	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="css/bootstrap.css">
	<link rel="stylesheet" href="vendors/linericon/style.css">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="vendors/owl-carousel/owl.carousel.min.css">
	<link rel="stylesheet" href="vendors/lightbox/simpleLightbox.css">
	<link rel="stylesheet" href="vendors/nice-select/css/nice-select.css">
	<link rel="stylesheet" href="vendors/animate-css/animate.css">
	<link rel="stylesheet" href="vendors/jquery-ui/jquery-ui.css">
	<!-- main css -->
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/responsive.css">
	<style>

.clickme {
    background-color: #0000ff;
    padding: 15px 40px;
    text-decoration:none;
    font-weight:bold;
    border-radius:6px;
    color: #ff0080;
    cursor:pointer;
}
body {
  font-family: "Lato", sans-serif;
}

.sidenav {
  height: 100%;
  width: 0;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #F0F3F4;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 60px;

}

.sidenav a {
  padding: 8px 8px 8px 32px;
  text-decoration: none;
  font-size: 15.5px;
  color: #080304;
  display: block;
  transition: 0.3s;
}

.sidenav a:hover {
  color: #0000FF;
}

.sidenav .closebtn {
  position: absolute;
  top: 0;
  right: 25px;
  font-size: 36px;
  margin-left: 50px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 10px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 10px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}

</style>	

</head>

<body>


  <style align="centre"> Welcome   {{Session::get('email')}}
           {{csrf_field() }}
          </style> 
	<!--================Header Menu Area =================-->
	<header class="header_area">
	<!--<div class="top_menu row m0">-->
			<div class="container">
			<div style="width:500px;margin-left:1000px;margin-top:20px;">
            
		  </div> 
          <div class="topright">
										 

                                         <span position="right" style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; </span>
                                         
                                         <div id="mySidenav" class="sidenav">
                                             <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
                                             <a href="/welcome">About</a>
                                             <a href="/departments">Departments</a>
                                             <a href="/doctors">Doctors</a>
                                             <a href="/addcart">Medicines</a>
                                             <a href="/updatepatientprofile">View Profile</a>
                                             <a href="/patientprofile">Edit Profile</a>
                                             <a href="/appointment">Appointment</a>
                                             <a href="/logout">Logout</a>
								
							</div>	
											
										</ul>
									</li>
							</div>
						</div>
					</div>
				</div>
			</nav>
		</div>
	</header>
	<!--================Header Menu Area =================-->

	<!--================ Home Banner Area =================-->
	




        
	<!--================ End Home Banner Area =================-->

	<!--================ Procedure Category Area =================-->
	
	<!--================ End Procedure Category Area =================-->

	<!--================ About Myself Area =================-->
	
	<!--================ End About Myself Area =================-->


	<!--================ Start Feedback Area =================-->
	
	<!--================ End Offered Services Area =================-->
   <!--================ Start Appointment Area =================-->
   <section class="appointment-area">
		<div class="container">
			<div class="row justify-content-between align-items-center appointment-wrap">
				<div class="col-lg-5 col-md-6 appointment-left">
				<img src="../../img/img.jpg" width="585p" height="600" >	
				</div>
				<div class="col-lg-6 col-md-6 pt-60 pb-60">
					<div class="appointment-right">
						<form class="form-wrap" action="#">
							<h3 class="pb-20 text-center mb-20">Medical Camps</h3>

                            <table>
  <tr>
    <th>Camp Name</th>
    <th>Venue</th>
    <th>Date</th>
    <th>Time</th>
    <th>Action</th>
  </tr>
                            
                                                <?php
                           use App\Camps;
                          // use App\Addspecilization;
                           $sql=DB::select('SELECT * FROM camps');
                           foreach($sql as $user)
                           {
                            $status=$user->status;
                            $id=$user->campid;
                            
                            ?>  
                           

                        
                                               
         <tr>
         
             
             <td>{{$user->campname}}</td>
             <td>{{$user->venue}}</td>
             <td>{{ $user->date}}</td>
             <td>{{  $user->time}}</td>
             <td><a href=""</a> Register</td>
            <!-- <td><a href='delete1/{{$user->campid}}' class='fa fa-trash'></a></td>-->
             
             </tr>
             
         
            <?php
                }
            ?>
         








							
								
								
							</div>
							
								
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!--================ End Appointment Area =================-->

	<!--================ Start recent-blog Area =================-->
	<section class="recent-blog-area</section>
	<!--================ end recent-blog Area =================-->

	<!--================ start footer Area =================-->
	<footer class="footer-area section_gap">
		
	</footer>
	<!--================ End footer Area =================-->



	<!--================ Optional JavaScript =================-->
	<!--================ jQuery first, then Popper.js, then Bootstrap JS =================-->
	<script src="js/jquery-3.2.1.min.js"></script>
	<script src="js/popper.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="vendors/nice-select/js/jquery.nice-select.min.js"></script>
	<script src="vendors/isotope/isotope-min.js"></script>
	<script src="vendors/owl-carousel/owl.carousel.min.js"></script>
	<script src="js/jquery.ajaxchimp.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/Counter-Up/1.0.0/jquery.counterup.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/waypoints/4.0.1/jquery.waypoints.min.js"></script>
	<script src="js/mail-script.js"></script>
	<script src="js/custom.js"></script>
	<script>
function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}
</script>
   
</body>

</html>

