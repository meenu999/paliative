<!doctype html>
<html lang="en">

<head>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="icon" href="img/favicon.png" type="image/png">
	<title>Hospice Medical</title>
    
	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="css/bootstrap.css">
	<link rel="stylesheet" href="vendors/linericon/style.css">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="vendors/owl-carousel/owl.carousel.min.css">
	<link rel="stylesheet" href="vendors/lightbox/simpleLightbox.css">
	<link rel="stylesheet" href="vendors/nice-select/css/nice-select.css">
	<link rel="stylesheet" href="vendors/animate-css/animate.css">
	<link rel="stylesheet" href="vendors/jquery-ui/jquery-ui.css">
	<!-- main css -->
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/responsive.css">
	<style>

.clickme {
    background-color: #0000ff;
    padding: 10px 50px;
    text-decoration:none;
    font-weight:bold;
    border-radius:6px;
    color: #ff0080;
    cursor:pointer;
}
input[type=text] {
  width: 130px;
  box-sizing: border-box;
  border: 2px solid #ccc;
  border-radius: 4px;
  font-size: 16px;
  background-color: white;
  background-image: url('searchicon.png');
  background-position: 10px 10px; 
  background-repeat: no-repeat;
  padding: 12px 20px 12px 40px;
  -webkit-transition: width 0.4s ease-in-out;
  transition: width 0.4s ease-in-out;
}

input[type=text]:focus {
  width: 100%;
}


</style>	

</head>

<body>



	<!--================Header Menu Area =================-->
	<header class="header_area">
		<div class="top_menu row m0">
			<div class="container">
            Welcome   {{Session::get('email')}}
           {{csrf_field() }}
		   
		   
				<!--<div class="float-left">
					<ul class="left_side">
						<li>
							<a href="login.html">
								<i class="fa fa-facebook-f"></i>
							</a>
						</li>
						<li>
							<a href="login.html">
								<i class="fa fa-twitter"></i>
							</a>
						</li>
						<li>
							<a href="login.html">
								<i class="fa fa-dribbble"></i>
							</a>
						</li>
						<li>
							<form>
				<input type="text" name="search" placeholder="Search..">
				</form>

						</li>
					</ul>
				</div>-->
				<!--<div class="float-right">
					<ul class="right_side">
						<li>
							<a href="/cart">
								<i class="fa fa-shopping-cart"></i>
								
							</a>
						</li>
						<li>
						
					<a href="/appointment"> <i class="clickme success">Appointment</i></a>
						</li>
					</ul>
				</div>
			</div>
		</div>-->
		<div class="main_menu">
			<nav class="navbar navbar-expand-lg navbar-light">
				<div class="container">
					<!-- Brand and toggle get grouped for better mobile display -->
					<a class="navbar-brand logo_h" href="index.html">
						<img src="img/logo.png" alt="">
					</a>
					<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
					 aria-expanded="false" aria-label="Toggle navigation">
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<!-- Collect the nav links, forms, and other content for toggling -->
				<!--	<div class="collapse navbar-collapse offset" id="navbarSupportedContent">
						<div class="row ml-0 w-100">
							<div class="col-lg-12 pr-0">
								<ul class="nav navbar-nav center_nav pull-right">
									<li class="nav-item active">
										<a class="nav-link" href="/welcome">Home</a>
									</li>
									<li class="nav-item ">
										<a class="nav-link" href="/departments">Departments</a>
									</li>
									<li class="nav-item ">
										<a class="nav-link" href="/doctors">Doctors</a>
									</li>
									<li class="nav-item ">
										<a class="nav-link" href="/addcart">Medicines</a>
										<!--<ul class="dropdown-menu">
											<li class="nav-item">
												<a class="nav-link" href="/about">About</a>
											</li>
											<li class="nav-item">
												<a class="nav-link" href="/services">Services</a>
											</li>
											
										</ul>-->
									<!--</li>
									<li class="nav-item submenu dropdown">
										<a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Profile</a>
										<ul class="dropdown-menu">
											<li class="nav-item">
												<a class="nav-link" href="/patientprofile">Edit Profile</a>
											</li>
											<li class="nav-item">
												<a class="nav-link" href="/updatepatientprofile">View Profile</a>
											</li>
										</ul>
									</li>-->
									<!--<li class="nav-item">
										<a class="nav-link" href="/patientprofile">Profile</a>
										<ul class="dropdown-menu">
											<li class="nav-item">
												<a class="nav-link" href="/about">About</a>
											</li>
											</ul>
									</li>-->

									<!--</li>
											<li class ="nav-item">
											<a class="nav-link" href="/logout">Logout</a>
											
										</ul>
									</li>-->
							</div>
						</div>
					</div>
				</div>
			</nav>
		</div>
	</header>
	<!--================Header Menu Area =================-->

	<!--================ Home Banner Area =================-->
	<section class="home_banner_area">
		<div class="banner_inner d-flex align-items-center">
			<div class="container">
				<div class="banner_content row">
				
					<div class="col-lg-12">
                    
						<h3>Sucessfully taken Appointment</h3>
						<p><a href="patienthome" class="btn btn-warning btn-block text-center"><span class="mr-10">Back to Home</span><span class="lnr lnr-arrow-right"></span></a> </p>
							

						
					</div>
				</div>
			</div>
		</div>
	</section>
	<!--================ End Home Banner Area =================-->

	<!--================ Procedure Category Area =================-->
	
	<!--================ End Procedure Category Area =================-->

	<!--================ About Myself Area =================-->
	
	<!--================ End About Myself Area =================-->


	<!--================ Start Feedback Area =================-->
	
	<!--================ End Feedback Area =================-->

	<!--================ Start Offered Services Area =================-->
	
	<!--================ End Offered Services Area =================-->


	<!--================ Start Appointment Area =================-->
	
	<!--================ End Appointment Area =================-->

	<!--================ Start recent-blog Area =================-->
	
	<!--================ end recent-blog Area =================-->

	<!--================ start footer Area =================-->
	
	<!--================ End footer Area =================-->



	<!--================ Optional JavaScript =================-->
	<!--================ jQuery first, then Popper.js, then Bootstrap JS =================-->
	<script src="js/jquery-3.2.1.min.js"></script>
	<script src="js/popper.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="vendors/nice-select/js/jquery.nice-select.min.js"></script>
	<script src="vendors/isotope/isotope-min.js"></script>
	<script src="vendors/owl-carousel/owl.carousel.min.js"></script>
	<script src="js/jquery.ajaxchimp.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/Counter-Up/1.0.0/jquery.counterup.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/waypoints/4.0.1/jquery.waypoints.min.js"></script>
	<script src="js/mail-script.js"></script>
	<script src="js/custom.js"></script>
</body>

</html>

