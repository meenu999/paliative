<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body, html {
  height: 100%;
  font-family: Arial, Helvetica, sans-serif;
}

* {
  box-sizing: border-box;
}

.bg-img {
  /* The image used */
  background-image: url("feedback-bg.jpg");

  min-height: 380px;

  /* Center and scale the image nicely */
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
  position: relative;
}

/* Add styles to the form container */
.container {
  position: absolute;
  right: 0;
  margin: 20px;
  max-width: 300px;
  padding: 16px;
  background-color: white;
}

/* Full-width input fields */
input[type=text], input[type=password] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  border: none;
  background: #f1f1f1;
}

input[type=text]:focus, input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}

/* Set a style for the submit button */
.btn {
  background-color: #4CAF50;
  color: white;
  padding: 16px 20px;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

.btn:hover {
  opacity: 1;
}
</style>
</head>
<body>

<h2>Feedback Form</h2>
<div class="bg-img">
  <form action="/feedback" class="container" method="post">
    <h1>Login</h1>

    <label for="email"><b>Patient Name</b></label>
    <input type="text" placeholder="Enter Patient name" name="pname" required autocomplete="off">

    <label for="psw"><b>Doctor Name </b></label>
    <input type="text" placeholder="Enter Doctor Name" name="dname" required   autocomplete="off">
    <label for="message"><b>Message</b></label>
    <select >
     <label for="message"><b>Message</b></label>  name="message">
                 <option value="Very Good">Very Good</option>
               <option value="Good">Good</option>
               <option value="Average">Average</option> 
               <option value="Poor">Poor</option>
               

</select>
    

    <button type="submit" class="btn">Submit</button>
  </form>
</div>

<p>

</body>
</html>
