<!--A Design by W3layouts
   Author: W3layout
   Author URL: http://w3layouts.com
   License: Creative Commons Attribution 3.0 Unported
   License URL: http://creativecommons.org/licenses/by/3.0/
   -->
<!DOCTYPE html>
<html lang="zxx">
   <head>
      <title>Sponser</title>
      <!--meta tags -->
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="keywords" content="Oblige Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
         Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
         <style>
body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box;}

/* Full-width input fields */
input[type=text], input[type=password] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}

/* Add a background color when the inputs get focus */
input[type=text]:focus, input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}

/* Set a style for all buttons */
button {
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

button:hover {
  opacity:1;
}

/* Extra styles for the cancel button */
.cancelbtn {
  padding: 14px 20px;
  background-color: #f44336;
}

/* Float cancel and signup buttons and add an equal width */
.cancelbtn, .signupbtn {
  float: left;
  width: 50%;
}

/* Add padding to container elements */
.container {
  padding: 16px;
}

/* The Modal (background) */
.modal {
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: #474e5d;
  padding-top: 50px;
}

/* Modal Content/Box */
.modal-content {
  background-color: #fefefe;
  margin: 5% auto 15% auto; /* 5% from the top, 15% from the bottom and centered */
  border: 1px solid #888;
  width: 80%; /* Could be more or less, depending on screen size */
}

/* Style the horizontal ruler */
hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}
 
/* The Close Button (x) */
.close {
  position: absolute;
  right: 35px;
  top: 15px;
  font-size: 40px;
  font-weight: bold;
  color: #f1f1f1;
}

.close:hover,
.close:focus {
  color: #f44336;
  cursor: pointer;
}

/* Clear floats */
.clearfix::after {
  content: "";
  clear: both;
  display: table;
}

/* Change styles for cancel button and signup button on extra small screens */
@media screen and (max-width: 300px) {
  .cancelbtn, .signupbtn {
     width: 100%;
  }
}
</style>
      <script>
         addEventListener("load", function () {
         	setTimeout(hideURLbar, 0);
         }, false);
         
         function hideURLbar() {
         	window.scrollTo(0, 1);
         }
      </script>
      <!--//meta tags ends here-->
      <!--booststrap-->
      <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" media="all">
      <!--//booststrap end-->
      <!-- font-awesome icons -->
      <link href="css/font-awesome.min.css" rel="stylesheet">
      <!-- //font-awesome icons -->
      <!--stylesheets-->
      <link href="css/style7.css" rel='stylesheet' type='text/css' media="all">
      <!--//stylesheets-->
      <link href="//fonts.googleapis.com/css?family=Fira+Sans:400,500,600,700" rel="stylesheet">
      <link href="//fonts.googleapis.com/css?family=Oxygen:400,700" rel="stylesheet">
   </head>
   <body>
      <div class="main-top" id="home">
         <!-- header -->
         <div class="headder-top">
            <div class="container-fluid">
               <!-- nav -->
               <nav >
                  <div id="logo">
                     <h1><a class="" href="">Hospice<span>Charity Fund </span></a></h1>
                  </div>
                  <label for="drop" class="toggle">Menu</label>
                  <input type="checkbox" id="drop">
                  <!--<ul class="menu mt-2">
                     <li class="active"><a href="sponserhome">Home</a></li>
                     <li class="mx-lg-3 mx-md-2 my-md-0 my-1"><a href="">About</a></li>-->
                     
                     <li class="mx-lg-3 mx-md-2 my-md-0 my-1">
                        <!-- First Tier Drop Down -->
                        
                        
                        <ul>
                           <li><a href="sponserhome" class="drop-text">Home</a></li>
                           <li><a href="/logout" class="drop-text">Logout</a></li>
                          <!-- <li><a href="" class="drop-text">Blog</a></li>-->
                        </ul>
                     </li>
                     
               </nav>
               <!-- //nav -->
            </div>
         </div>
         <!-- //header -->
         <!-- banner -->
         <div class="main-banner">
         
            <div class="container">
               <div class="style-banner ">
                  <h4 class="mb-1">Better Care and Better World</h4>
                  <h5>You have a good life,some other don't
                  </h5>
               </div>
               <div class="two-demo-button mt-lg-4 mt-3">
                  <p> “In the end, though, maybe we must all give up trying to pay back the people in this world who sustain our lives. In the end, maybe it's wiser to surrender before the miraculous scope of human generosity and to just keep saying thank you, forever and sincerely, for as long as we have voices.”  </p>
               </div>
               <div class="view-buttn mt-md-4 mt-sm-4 mt-3">
                  
<!--<a href="makepayment" class="btn scroll">Make Payment</a>-->
<button onclick="document.getElementById('id01').style.display='block'" style="width:auto;">Make Payment</button>

<div id="id01" class="modal">
  <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span>
  <form action="/amount"  class="modal-content"  method="get">

  <input type="hidden" name="_token" value="{{csrf_token()}}">	
  
  
    <div class="container">
   
      <h1>Make Payment</h1>
      <p>Please fill in this form to make payment.</p>
      <hr>
      <label for="amount"><b>Amount</b></label>
      <input type="text" placeholder="Enter Amount" name="amount" autocomplete="off" required >

     <!-- <label for="psw"><b>Password</b></label>
      <input type="password" placeholder="Enter Password" name="psw" required>

      <label for="psw-repeat"><b>Repeat Password</b></label>
      <input type="password" placeholder="Repeat Password" name="psw-repeat" required>-->
      
      <!-- <label>
        <input type="checkbox" checked="checked" name="remember" style="margin-bottom:15px"> Remember me
      </label>

      <p>By creating an account you agree to our <a href="#" style="color:dodgerblue">Terms & Privacy</a>.</p> -->

      <div class="clearfix">
       <button type="button" onclick="document.getElementById('id01').style.display='none'" class="cancelbtn">Cancel</button>
        <button type="submit" class="signupbtn">Continue</button>
       <!--<input type="submit" class="btn btn-warning btn-block text-center" name="submit" value="Add ">-->
        
      </div>
    </div>
  </form>
</div>
               </div>
            </div>
         </div>
      </div>
      <!-- //banner -->
      <section class="three-grids">
         <div class="container-fluid">
            <div class="row">
               <div class="col-lg-3 col-md-6 col-sm-6 p-0">
                  <div class="img-abt-info1">
                  </div>
               </div>
               <div class="col-lg-3 col-md-6 col-sm-6 banner-bottom-grid p-0">
                  <div class="w3layouts-abt-info">
                     <div class="mb-lg-3 mb-md-3 mb-2 abut-headder">
                        <h4>Donation</h4>
                     </div>
                     <p>sed do eiusmod tempor incididunt ut Lorem ipsum dolor sit amet</p>
                     <div class="view-price mt-3">
                        <a href="#contact" class=" scroll">Read More</a>
                     </div>
                  </div>
               </div>
               <div class="col-lg-3 col-md-6 col-sm-6 p-0">
                  <div class="img-abt-info2">
                  </div>
               </div>
               <div class="col-lg-3 col-md-6 col-sm-6 banner-bottom-grid p-0">
                  <div class="w3layouts-abt-info">
                     <div class="mb-lg-3 mb-md-3 mb-2 abut-headder">
                        <h4>Fundrising</h4>
                     </div>
                     <p>sed do eiusmod tempor incididunt ut Lorem ipsum dolor sit amet</p>
                     <div class="view-price mt-3">
                        <a href="#contact" class=" scroll">Read More</a>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- about -->
      <section class="about py-lg-4 py-md-3 py-sm-3 py-3" id="about">
         <div class="container py-lg-5 py-md-4 py-sm-4 py-3">
            <div class="row">
               <div class="col-lg-7 col-md-6">
                  <div class="wthree-about-txt mb-lg-5 mb-md-4 mb-3">
                     <h5>Our Mission</h5>
                  </div>
                  <div class="about-para-txt">
                     <p>sed do eiusmod tempor incididunt ut Lorem ipsum dolor sit amet Lorem ipsum dolor sit amet, eiusmod tempor incididunt ut labore et consectetur adipiscing sed do eiusmod tempor incididunt ut Lorem ipsum dolor sit amet Lorem ipsum dolor sit amet, eiusmod tempor incididunt ut labore et consectetur adipiscing</p>
                     <p class="mt-2">sed do eiusmod tempor incididunt ut Lorem ipsum dolor sit amet Lorem ipsum dolor sit amet, eiusmod tempor incididunt ut labore et consectetur adipiscing sed do eiusmod</p>
                  </div>
                  <div class="view-price mt-lg-5 mt-md-4 mt-3">
                     <a href="#contact" class=" scroll">Read More</a>
                  </div>
               </div>
               <div class="col-lg-5 col-md-6 about-imgs-txt">
               </div>
            </div>
         </div>
      </section>
      <!-- about  -->
      <!--state -->
      <section class="stats py-lg-4 py-md-3 py-sm-3 py-3">
         <div class="container py-lg-5 py-md-4 py-sm-4 py-3">
            <div class="stats-info row ">
               <div class="col-lg-3 col-md-3 col-sm-6 col-6 stats-grid ">
                  <div class="register-left-num ">
                     <div class="count-icon">
                        <span class="fa fa-paw" aria-hidden="true"></span>
                     </div>
                     <div class="counter-number">1200</div>
                     <div class="stat-info pt-lg-3 pt-md-3 pt-sm-3 pt-3">
                        <h4>Donation</h4>
                     </div>
                  </div>
               </div>
               <div class="col-lg-3 col-md-3 col-sm-6 col-6 stats-grid ">
                  <div class="register-left-num">
                     <div class="count-icon">
                        <span class="fa fa-smile-o" aria-hidden="true"></span>
                     </div>
                     <div class="counter-number">2000</div>
                     <div class="stat-info pt-lg-3 pt-md-3 pt-sm-3 pt-3">
                        <h4>Volunteers</h4>
                     </div>
                  </div>
               </div>
               <div class="col-lg-3 col-md-3 col-sm-6 col-6 stats-grid">
                  <div class="register-left-num">
                     <div class="count-icon">
                        <span class="fa fa-leaf" aria-hidden="true"></span>
                     </div>
                     <div class="counter-number">4000</div>
                     <div class="stat-info pt-lg-3 pt-md-3 pt-sm-3 pt-3">
                        <h4>Rescued</h4>
                     </div>
                  </div>
               </div>
               <div class="col-lg-3 col-md-3 col-sm-6 col-6 stats-grid">
                  <div class="register-left-num">
                     <div class="count-icon">
                        <span class="fa fa-globe" aria-hidden="true"></span>
                     </div>
                     <div class="counter-number">30+</div>
                     <div class="stat-info pt-lg-3 pt-md-3 pt-sm-3 pt-3">
                        <h4>Countries</h4>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!--//state -->
      <!-- service -->
      <section class="service py-lg-4 py-md-3 py-sm-3 py-3" id="service">
         <div class="container py-lg-5 py-md-4 py-sm-4 py-3">
            <h3 class="title text-center mb-md-4 mb-sm-3 mb-3 mb-2">Our Service</h3>
            <div class="title-wls-text text-center mb-lg-5 mb-md-4 mb-sm-4 mb-3">
               <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et Lorem ipsum </p>
            </div>
            <div class="row">
               <div class="col-lg-5 service-two-grids">
                  <div class="color-img-five">
                     <div class="ser-sevice-grid text-center">
                        <h4 class="pb-3">Make A Donation</h4>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum nibh urna, euismod ut ornare non Lorem ipsum dolor sit amet Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum nibh urna, euismod ut ornare non Lorem ipsum dolor sit amet</p>
                     </div>
                  </div>
               </div>
               <div class="col-lg-7 service-two-grids">
                  <div class="img-cols-grid row">
                     <div class="col-lg-6 col-md-6 col-sm-6">
                        <div class=" color-img-one" >
                           <div class="ser-sevice-grid text-center">
                              <h4 class="pb-3">Become volunteer</h4>
                              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum nibh urna</p>
                           </div>
                        </div>
                     </div>
                     <div class="col-lg-6 col-md-6 col-sm-6 ">
                        <div class=" color-img-two">
                           <div class="ser-sevice-grid text-center">
                              <h4 class="pb-3">Make A Donation</h4>
                              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum nibh urna</p>
                           </div>
                        </div>
                     </div>
                     <div class="col-lg-6 col-md-6 col-sm-6 mt-md-4 mt-3">
                        <div class=" color-img-three">
                           <div class="ser-sevice-grid text-center">
                              <h4 class="pb-3">Sponsor a Child</h4>
                              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum nibh urna</p>
                           </div>
                        </div>
                     </div>
                     <div class="col-lg-6 col-md-6 col-sm-6 mt-md-4 mt-3">
                        <div class=" color-img-four">
                           <div class="ser-sevice-grid text-center">
                              <h4 class="pb-3">Human Rights</h4>
                              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum nibh urna</p>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!--//service -->
      <!--team -->
      <section class="team py-lg-4 py-md-3 py-sm-3 py-3" id="team">
         <div class="container py-lg-5 py-md-4 py-sm-4 py-3">
            <h3 class="title text-center mb-md-4 mb-sm-3 mb-3 mb-2 clr">Our Volunteers</h3>
            <div class="title-wls-text text-center mb-lg-5 mb-md-4 mb-sm-4 mb-3 sub-colors">
               <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et Lorem ipsum </p>
            </div>
            <div class="row ">
               <div class="col-lg-3 col-md-6 col-sm-6 team-grid-colum text-center">
                  <img src="images/t1.jpg" alt="" class="img-fluid">
                  <div class="text-grid-gried">
                     <h4>Atticus Will</h4>
                     <ul class="d-flex justify-content-center pt-3 social-icons">
                        <li>
                           <a href="#">
                           <span class="fa fa-facebook-f"></span>
                           </a>
                        </li>
                        <li class="mx-3">
                           <a href="#">
                           <span class="fa fa-twitter"></span>
                           </a>
                        </li>
                        <li>
                           <a href="#">
                           <span class="fa fa-google-plus"></span>
                           </a>
                        </li>
                     </ul>
                  </div>
               </div>
               <div class="col-lg-3 col-md-6 col-sm-6 team-grid-colum text-center">
                  <img src="images/t2.jpg" alt="" class="img-fluid">
                  <div class="text-grid-gried">
                     <h4>Jacob Will</h4>
                     <ul class="d-flex justify-content-center pt-3 social-icons">
                        <li>
                           <a href="#">
                           <span class="fa fa-facebook-f"></span>
                           </a>
                        </li>
                        <li class="mx-3">
                           <a href="#">
                           <span class="fa fa-twitter"></span>
                           </a>
                        </li>
                        <li>
                           <a href="#">
                           <span class="fa fa-google-plus"></span>
                           </a>
                        </li>
                     </ul>
                  </div>
               </div>
               <div class="col-lg-3 col-md-6 col-sm-6 team-grid-colum text-center">
                  <img src="images/t3.jpg" alt="" class="img-fluid">
                  <div class="text-grid-gried">
                     <h4>Isabella Den</h4>
                     <ul class="d-flex justify-content-center pt-3 social-icons">
                        <li>
                           <a href="#">
                           <span class="fa fa-facebook-f"></span>
                           </a>
                        </li>
                        <li class="mx-3">
                           <a href="#">
                           <span class="fa fa-twitter"></span>
                           </a>
                        </li>
                        <li>
                           <a href="#">
                           <span class="fa fa-google-plus"></span>
                           </a>
                        </li>
                     </ul>
                  </div>
               </div>
               <div class="col-lg-3 col-md-6 col-sm-6 team-grid-colum text-center">
                  <img src="images/t4.jpg" alt="" class="img-fluid">
                  <div class="text-grid-gried">
                     <h4>Liam Willson</h4>
                     <ul class="d-flex justify-content-center pt-3 social-icons">
                        <li>
                           <a href="#">
                           <span class="fa fa-facebook-f"></span>
                           </a>
                        </li>
                        <li class="mx-3">
                           <a href="#">
                           <span class="fa fa-twitter"></span>
                           </a>
                        </li>
                        <li>
                           <a href="#">
                           <span class="fa fa-google-plus"></span>
                           </a>
                        </li>
                     </ul>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!--//team -->
      <!-- gallery-main -->
      <section class="gallery py-lg-4 py-md-3 py-sm-3 py-3" id="gallery">
         <div class="container py-lg-5 py-md-4 py-sm-4 py-3">
            <h3 class="title text-center mb-md-4 mb-sm-3 mb-3 mb-2">Our Gallery</h3>
            <div class="title-wls-text text-center mb-lg-5 mb-md-4 mb-sm-4 mb-3">
               <p >Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et Lorem ipsum 
               </p>
            </div>
            <div class="row gallery-info">
               <div class="col-lg-3 col-md-3 col-sm-6 gallery-img-grid p-0">
                  <div class="gallery-grids">
                     <a href="#gal1"><img src="images/g1.jpg" alt="news image" class="img-fluid"></a>
                  </div>
               </div>
               <div class="col-lg-3 col-md-3 col-sm-6 gallery-img-grid p-0">
                  <div class="gallery-grids">
                     <a href="#gal2"><img src="images/g2.jpg" alt="news image" class="img-fluid"></a>
                  </div>
               </div>
               <div class="col-lg-3 col-md-3 col-sm-6 gallery-img-grid p-0">
                  <div class="gallery-grids">
                     <a href="#gal3"><img src="images/g3.jpg" alt="news image" class="img-fluid"></a>
                  </div>
               </div>
               <div class="col-lg-3 col-md-3 col-sm-6 gallery-img-grid p-0">
                  <div class="gallery-grids p-0">
                     <a href="#gal4"><img src="images/g4.jpg" alt="news image" class="img-fluid"></a>
                  </div>
               </div>
               <div class="col-lg-6 col-md-6 col-sm-6 gallery-img-grid gallery-mid-two p-0">
                  <div class="gallery-grids">
                     <a href="#gal5"><img src="images/g5.jpg" alt="news image" class="img-fluid"></a>
                  </div>
               </div>
               <div class="col-lg-6 col-md-6 col-sm-6 gallery-img-grid gallery-mid-two p-0">
                  <div class="gallery-grids">
                     <a href="#gal6"><img src="images/g6.jpg" alt="news image" class="img-fluid"></a>
                  </div>
               </div>
               <div class="col-lg-4 col-md-4 col-sm-12 gallery-img-three p-0">
                  <div class="gallery-grids">
                     <a href="#gal7"><img src="images/g7.jpg" alt="news image" class="img-fluid"></a>
                  </div>
               </div>
               <div class="col-lg-4 col-md-4 col-sm-12 gallery-img-three p-0">
                  <div class="gallery-grids">
                     <a href="#gal8"><img src="images/g8.jpg" alt="news image" class="img-fluid"></a>
                  </div>
               </div>
               <div class="col-lg-4 col-md-4 col-sm-12 gallery-img-three p-0">
                  <div class="gallery-grids">
                     <a href="#gal9"><img src="images/g9.jpg" alt="news image" class="img-fluid"></a>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!--// gallery-main -->
      <!-- popup-->
      <div id="gal1" class="popup-effect">
         <div class="popup">
            <img src="images/g1.jpg" alt="Popup Image" class="img-fluid" />
            <a class="close" href="#gallery">&times;</a>
         </div>
      </div>
      <!-- //popup -->
      <!-- popup-->
      <div id="gal2" class="popup-effect">
         <div class="popup">
            <img src="images/g2.jpg" alt="Popup Image" class="img-fluid" />
            <a class="close" href="#gallery">&times;</a>
         </div>
      </div>
      <!-- //popup -->
      <!-- popup-->
      <div id="gal3" class="popup-effect">
         <div class="popup">
            <img src="images/g3.jpg" alt="Popup Image" class="img-fluid" />
            <a class="close" href="#gallery">&times;</a>
         </div>
      </div>
      <!-- //popup -->
      <!-- popup-->
      <div id="gal4" class="popup-effect">
         <div class="popup">
            <img src="images/g4.jpg" alt="Popup Image" class="img-fluid" />
            <a class="close" href="#gallery">&times;</a>
         </div>
      </div>
      <!-- //popup -->
      <!-- popup-->
      <div id="gal5" class="popup-effect">
         <div class="popup">
            <img src="images/g5.jpg" alt="Popup Image" class="img-fluid" />
            <a class="close" href="#gallery">&times;</a>
         </div>
      </div>
      <!-- //popup -->
      <!-- popup-->
      <div id="gal6" class="popup-effect">
         <div class="popup">
            <img src="images/g6.jpg" alt="Popup Image" class="img-fluid" />
            <a class="close" href="#gallery">&times;</a>
         </div>
      </div>
      <!-- //popup -->
      <!-- popup-->
      <div id="gal7" class="popup-effect">
         <div class="popup">
            <img src="images/g7.jpg" alt="Popup Image" class="img-fluid" />
            <a class="close" href="#gallery">&times;</a>
         </div>
      </div>
      <!-- //popup -->
      <!-- popup-->
      <div id="gal8" class="popup-effect">
         <div class="popup">
            <img src="images/g8.jpg" alt="Popup Image" class="img-fluid" />
            <a class="close" href="#gallery">&times;</a>
         </div>
      </div>
      <!-- //popup -->
      <!-- popup-->
      <div id="gal9" class="popup-effect">
         <div class="popup">
            <img src="images/g9.jpg" alt="Popup Image" class="img-fluid" />
            <a class="close" href="#gallery">&times;</a>
         </div>
      </div>
      <!-- //popup -->
      <!-- //gallery popups -->
      <!-- //gallery -->
      <!-- blog -->
      <section class="blog py-lg-4 py-md-3 py-sm-3 py-3" id="blog">
         <div class="container-fluid py-lg-5 py-md-4 py-sm-4 py-3">
            <h3 class="title text-center mb-md-4 mb-sm-3 mb-3 mb-2">Latest Blog</h3>
            <div class="title-wls-text text-center mb-lg-5 mb-md-4 mb-sm-4 mb-3">
               <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et Lorem ipsum </p>
            </div>
            <div class="row">
               <div class="col-lg-3 col-md-6 col-sm-6 busness-tip-one">
               </div>
               <div class="col-lg-3 col-md-6 col-sm-6 mid-text-info">
                  <div class="blog-info">
                     <a href="#contact" class="scroll">
                        <ul>
                           <li>JUL</li>
                           <li>15</li>
                        </ul>
                     </a>
                  </div>
                  <h4 class="mb-lg-4 mb-3"><a href="#contact">Better Care and Better World</a></h4>
                  <p>Lorem Ipsum is simply text the printing and typesetting standard industry.Lorem Ipsum has been the industry's standard
                  </p>
               </div>
               <div class="col-lg-3 col-md-6 col-sm-6 busness-tip-two ">
               </div>
               <div class="col-lg-3 col-md-6 col-sm-6 mid-text-info">
                  <div class="blog-info">
                     <a href="#contact" class="scroll">
                        <ul>
                           <li>JUL</li>
                           <li>15</li>
                        </ul>
                     </a>
                  </div>
                  <h4 class="mb-lg-4 mb-3"><a href="#contact">We Need Your Help For Rescue Child</a></h4>
                  <p>Lorem Ipsum is simply text the printing and typesetting standard industry. Lorem Ipsum has been the industry's standard
                  </p>
               </div>
            </div>
            <div class="row">
               <div class="col-lg-3 col-md-6 col-sm-6 mid-text-info">
                  <h4 class="mb-lg-4 mb-3"><a href="#contact">Better Care and Better World</a></h4>
                  <p>Lorem Ipsum is simply text the printing and typesetting standard industry. Lorem Ipsum has been the industry's standard
                  </p>
               </div>
               <div class="col-lg-3 col-md-6 col-sm-6 busness-tip-two ">
                  <div class="blog-info">
                     <a href="#contact" class="scroll">
                        <ul>
                           <li>JUL</li>
                           <li>15</li>
                        </ul>
                     </a>
                  </div>
               </div>
               <div class="col-lg-3 col-md-6 col-sm-6 mid-text-info">
                  <h4 class="mb-lg-4 mb-3"><a href="#contact">We Need Your Help For Rescue Child</a></h4>
                  <p>Lorem Ipsum is simply text the printing and typesetting standard industry. Lorem Ipsum has been the industry's standard
                  </p>
               </div>
               <div class="col-lg-3 col-md-6 col-sm-6 busness-tip-one pl-sm-0">
                  <div class="blog-info">
                     <a href="#contact" class="scroll">
                        <ul>
                           <li>JUL</li>
                           <li>15</li>
                        </ul>
                     </a>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- //blog -->
      <!-- Info-matter -->
      <section class="info-matter py-lg-4 py-md-3 py-sm-3 py-3" id="info-matter">
         <div class="container py-lg-5 py-md-4 py-sm-4 py-3">
            <div class="row">
               <div class="col-lg-6 text-sm-center">
                  <img src="images/info.png" alt="" class="img-fluid">
               </div>
               <div class="col-lg-6 info-matter-join mt-lg-4 mt-3">
                  <h5 class="mb-lg-4 mb-3">Are You A Volunteer Ready?</h5>
                  <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et Lorem ipsum 
                  </p>
                  <p class="mt-2">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et Lorem ipsum 
                  </p>
                  <div class="view-buttn mt-md-4 mt-sm-4 mt-3">
                     <a href="#contact" class="btn scroll">Join Us</a>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!--// Info-matter-->
      <!-- contact -->
      <section class="contact py-lg-4 py-md-3 py-sm-3 py-3" id="contact">
         <div class="container py-lg-5 py-md-4 py-sm-4 py-3">
            <h3 class="title text-center mb-md-4 mb-sm-3 mb-3 mb-2">contact Us</h3>
            <div class="title-wls-text text-center mb-lg-5 mb-md-4 mb-sm-4 mb-3">
               <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et Lorem ipsum 
               </p>
            </div>
            <div class="row">
               <div class="col-lg-6 col-md-6 contact-details">
                  <form action="#" method="post">
                     <div class=" form-group contact-forms">
                        <input type="text" class="form-control" placeholder="Name" required="">
                     </div>
                     <div class="form-group contact-forms">
                        <input type="email" class="form-control" placeholder="Email" required="">
                     </div>
                     <div class="form-group contact-forms">
                        <input type="text" class="form-control" placeholder="Phone" required=""> 
                     </div>
                     <div class="form-group contact-forms">
                        <textarea class="form-control" placeholder="Message" rows="3" required=""></textarea>
                     </div>
                     <button type="submit" class="btn sent-butnn">Send</button>
                  </form>
               </div>
               <div class="col-lg-6 col-md-6 address-grid text-center">
                  <div class="contact-address-info mb-md-4 mb-3">
                     <h2><a href="index.html">Funding</a></h2>
                  </div>
                  <div class="contact-address-grid mb-3">
                     <h4> Address</h4>
                  </div>
                  <div class=" footer-contact-list mb-2">
                     <p>Melbourne,south Brisbane,<br>QLD 4101,Aurstralia.</p>
                  </div>
                  <div class=" footer-contact-list mb-2">
                     <p>+ 1 (234) 567 8901</p>
                  </div>
                  <div class=" footer-contact-list mb-2">
                     <p><a href="mailto:info@example.com">info2@example.com</a></p>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!--//contact -->
      <div class="address_mail_footer_grids">
   <!-- <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3539.812628729253!2d153.014155!3d-27.4750921!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6b915a0835840a2f%3A0xdd5e3f5c208dc0e1!2sMelbourne+St%2C+South+Brisbane+QLD+4101%2C+Australia!5e0!3m2!1sen!2sin!4v1492257477691"></iframe>-->$http_response_header
      </div>
      <!-- footer -->
      <footer class=" py-3">
         <div class="container">
            <div class="icons mt-3 text-center">
               <ul class="d-flex justify-content-center pb-3 social-icons">
                  <li>
                     <a href="#">
                     <span class="fa fa-facebook-f"></span>
                     </a>
                  </li>
                  <li class="mx-3">
                     <a href="#">
                     <span class="fa fa-twitter"></span>
                     </a>
                  </li>
                  <li class="mr-3">
                     <a href="#">
                     <span class="fa fa-google-plus"></span>
                     </a>
                  </li>
                  <li><a href="#"><span class="fa fa-vk"></span></a></li>
               </ul>
            </div>
         </div>
         <div class="footer-main txt-center">
            
            </p>
         </div>
         <!-- move icon -->
         <div class="txt-center">
            <a href="#home" class="move-top txt-center mt-3"></a>
         </div>
         <!--//move icon -->
      </footer>
      <!--//footer -->
      <script>
// Get the modal
var modal = document.getElementById('id01');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}
</script>

   </body>
</html>