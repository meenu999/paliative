<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" href="img/favicon.png" type="image/png">
    <title>Blog</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="vendors/linericon/style.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="vendors/owl-carousel/owl.carousel.min.css">
    <link rel="stylesheet" href="vendors/lightbox/simpleLightbox.css">
    <link rel="stylesheet" href="vendors/nice-select/css/nice-select.css">
    <link rel="stylesheet" href="vendors/animate-css/animate.css">
    <!-- main css -->
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
</head>

<body>

    <!--================Header Menu Area =================-->
	<header class="header_area">
		<div class="top_menu row m0">
			<div class="container">
				<div class="float-left">
					<ul class="left_side">
						<li>
							
						</li>
						<li>
							
						</li>
						<li>
							
						</li>
						<li>
							
						</li>
					</ul>
				</div>
				<div class="float-right">
					<!--<ul class="right_side">
						<li>
							<a href="login.html">
								<i class="lnr lnr-phone-handset"></i>
								751-064-0779
							</a>
						</li>
						<li>
							<a href="#">
								<i class="lnr lnr-envelope"></i>
								emergency@hospice.com
							</a>
						</li>
					</ul>-->
				</div>
			</div>
		</div>
		<div class="main_menu">
			<nav class="navbar navbar-expand-lg navbar-light">
				<div class="container">
					<!-- Brand and toggle get grouped for better mobile display -->
					<a class="navbar-brand logo_h" href="index.html">
						<img src="img/logo.png" alt="">
					</a>
					<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
					 aria-expanded="false" aria-label="Toggle navigation">
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<!-- Collect the nav links, forms, and other content for toggling -->
					<div class="collapse navbar-collapse offset" id="navbarSupportedContent">
						<div class="row ml-0 w-100">
							<div class="col-lg-12 pr-0">
								<ul class="nav navbar-nav center_nav pull-right">
									<li class="nav-item active">
										<a class="nav-link" href="/welcome">Home</a>
									</li>
									<li class="nav-item">
										<a class="nav-link" href="/departments">Departments</a>
									</li>
									<li class="nav-item">
										<a class="nav-link" href="/doctors">Doctors</a>
									</li>
									<li class="nav-item submenu dropdown">
										<a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Pages</a>
										<ul class="dropdown-menu">
											<li class="nav-item">
												<a class="nav-link" href="/about">About</a>
											</li>
											<li class="nav-item">
												<a class="nav-link" href="/services">Services</a>
											</li>
											
										</ul>
									</li>
									<li class="nav-item submenu dropdown active">
										<a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Blog</a>
										<ul class="dropdown-menu">
											<li class="nav-item">
												<a class="nav-link" href="/blog">Blog</a>
											</li>
											
										</ul>
									</li>
									<li class="nav-item">
										<a class="nav-link" href="/contact">Contact</a>
									</li>
								
											
										</ul>
									</li>
							</div>
						</div>
					</div>
				</div>
			</nav>
		</div>
	</header>
	<!--================Header Menu Area =================-->

    <!--================ Home Banner Area =================-->
    <section class="home_banner_area">
        <div class="banner_inner d-flex align-items-center">
            <div class="container">
                <div class="banner_content row">
                    <div class="col-lg-12">
                        <h1>We Care for Your Health Every Moment</h1>
                        <p>If you are looking at blank cassettes on the web, you may be very confused at the difference in price
                            You may see some for as low as each.</p>
                        
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--================ End Home Banner Area =================-->

    <!--================Blog Categorie Area =================-->
    <section class="blog_categorie_area">
        <div class="container">
            <div class="row">
                <div class="col-lg-4">
                    <div class="categories_post">
                        <img src="img/banner/about.jpg" alt="post">
                        <p>
						What is hospice care?
“You matter because of who you are. You matter to the last moment of your life, and we will do all we can , not only to help you die peacefully, but also to live until you die.”

--Dame Cicely Saunders

Hospice care focuses on the quality of life rather than its length. It provides humane and compassionate care for people in the last phases of incurable disease so that they may live as fully and comfortably as possible.

The hospice philosophy accepts death as the final stage of life: it affirms life and neither hastens nor postpones death. Hospice care treats the person rather than the disease, working to manage symptoms so that a person’s last days may be spent with dignity and quality, surrounded by their loved ones. Hospice care is also family-centered – it includes the patient and the family in making decisions.

Hospice care is used when you can no longer be helped by curative treatment and are expected to live about 6 months or less if the illness runs its usual course. Hospice gives you supportive or palliative care, which is treatment to help relieve symptoms, but not cure the disease. Its main purpose is to improve your quality of life. You, your family members, and your doctor decide when hospice care should begin.

Hospice often is not started soon enough. Sometimes the doctor, patient, or family member will resist hospice because they think it means “giving up” or that there’s no hope. This is not true. You can leave hospice and go into active cancer treatment any time you want. But the hope that hospice brings is a quality life, making the best of each day during the last stages of advanced illness.

Some doctors don’t bring up hospice, so the patient or family member might decide to start the conversation. If your treatment isn’t working anymore and you’ve run out of treatment options, you might want to ask your doctor or a member of your cancer care team about hospice.

What does hospice care provide?
All hospices must provide certain services, but they tend to have different approaches to service, staffing patterns, and types of support services offered.

Pain and symptom control
The goal of pain and symptom control is to help you be comfortable while allowing you to stay in control of and enjoy your life. This means that discomfort, pain, nausea, and other side effects are managed to make sure that you feel as good as possible, yet are alert enough to enjoy the people around you and make important decisions.

Home care and inpatient care
Although most hospice care is centered in the home, there might be times when you need to be in a hospital, extended-care facility, or an inpatient hospice center. Your home hospice team can arrange for inpatient care and will stay involved in your care and with your family. You can go back to in-home care when you and your family are ready.

Spiritual care
Since people differ in their spiritual needs and religious beliefs, spiritual care is set up to meet your specific needs. It might include helping you look at what death means to you, helping you say good-bye, or helping with a certain religious ceremony or ritual.

Family meetings
Regularly scheduled meetings, often led by the hospice nurse or social worker, keep family members informed about your condition and what to expect. These meetings also give everyone a chance to share feelings, talk about what’s happening and what’s needed, and learn about death and the process of dying. Family members can get great support and stress relief through these meetings. Daily updates may also be given informally as the nurse or nursing assistant talks with you and your caregivers during routine visits.

Coordination of care
The hospice team coordinates and supervises all care 7 days a week, 24 hours a day. This team is responsible for making sure that all involved services share information. This may include the inpatient facility, the doctor, and other community professionals, such as pharmacists, clergy, and funeral directors. You and your caregivers are encouraged to contact your hospice team if you’re having a problem, any time of the day or night. There’s always someone on call to help you with whatever may arise. Hospice care assures you and your family that you are not alone and can get help at any time.

Respite care
For patients being cared for at home, some hospice services offer respite care to allow friends and family some time away from caregiving. Respite care can be given in up to 5-day periods of time, during which the person with cancer is cared for either in the hospice facility or in beds that are set aside in nursing homes or hospitals. Families can plan a mini-vacation, go to special events, or simply get much-needed rest at home while you’re cared for in an inpatient setting.

Bereavement care
Bereavement is the period of mourning after a loss. The hospice care team works with surviving loved ones to help them through the grieving process. A trained volunteer, clergy member, or professional counselor provides support to survivors through visits, phone calls, and/or other contact, as well as through support groups. The hospice team can refer family members and caregiving friends to other medical or professional care if needed. Bereavement services are often provided for about a year after the patient’s death.
								    
								</p>

                        <div class="left-agileinfo same">
                        <img src="img/download (1).jpg" alt="post">
								
</div>								
                                    
    <!--================ End footer Area =================-->




    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/popper.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/stellar.js"></script>
    <script src="vendors/lightbox/simpleLightbox.min.js"></script>
    <script src="vendors/nice-select/js/jquery.nice-select.min.js"></script>
    <script src="vendors/isotope/imagesloaded.pkgd.min.js"></script>
    <script src="vendors/isotope/isotope-min.js"></script>
    <script src="vendors/owl-carousel/owl.carousel.min.js"></script>
    <script src="vendors/jquery-ui/jquery-ui.js"></script>
    <script src="js/jquery.ajaxchimp.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Counter-Up/1.0.0/jquery.counterup.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/waypoints/4.0.1/jquery.waypoints.min.js"></script>
    <script src="js/mail-script.js"></script>
    <script src="vendors/jquery-ui/jquery-ui.js"></script>
    <script src="js/theme.js"></script>
    <script src="js/custom.js"></script>
</body>

</html>