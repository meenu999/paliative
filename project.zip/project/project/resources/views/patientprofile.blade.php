<!doctype html>
<html lang="en">

<head>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="icon" href="img/favicon.png" type="image/png">
	<title>Hospice Medical</title>
    
	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="css/bootstrap.css">
	<link rel="stylesheet" href="vendors/linericon/style.css">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="vendors/owl-carousel/owl.carousel.min.css">
	<link rel="stylesheet" href="vendors/lightbox/simpleLightbox.css">
	<link rel="stylesheet" href="vendors/nice-select/css/nice-select.css">
	<link rel="stylesheet" href="vendors/animate-css/animate.css">
	<link rel="stylesheet" href="vendors/jquery-ui/jquery-ui.css">
	<!-- main css -->
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/responsive.css">
</head>

<body>



	<!--================Header Menu Area =================-->
	<header class="header_area">
		<div class="top_menu row m0">
			<div class="container">
            Welcome   {{Session::get('email')}}
           {{csrf_field() }}
				<!--<div class="float-left">
					<ul class="left_side">
						<li>
							<a href="login.html">
								<i class="fa fa-facebook-f"></i>
							</a>
						</li>
						<li>
							<a href="login.html">
								<i class="fa fa-twitter"></i>
							</a>
						</li>
						<li>
							<a href="login.html">
								<i class="fa fa-dribbble"></i>
							</a>
						</li>
						<li>
							<a href="login.html">
								<i class="fa fa-behance"></i>
							</a>
						</li>
					</ul>
				</div>-->
				<div class="float-right">
					<ul class="right_side">
						<li>
							<a href="login.html">
								<i class="lnr lnr-phone-handset"></i>
								6532-568-9746
							</a>
						</li>
						<li>
							<a href="#">
								<i class="lnr lnr-envelope"></i>
								emergency@hospicegmail.com
							</a>
						</li>
					</ul>
				</div>
			</div>
		</div>
		<div class="main_menu">
			<nav class="navbar navbar-expand-lg navbar-light">
				<div class="container">
					<!-- Brand and toggle get grouped for better mobile display -->
					<a class="navbar-brand logo_h" href="index.html">
						<img src="img/logo.png" alt="">
					</a>
					<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
					 aria-expanded="false" aria-label="Toggle navigation">
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<!-- Collect the nav links, forms, and other content for toggling -->
					<div class="collapse navbar-collapse offset" id="navbarSupportedContent">
						<div class="row ml-0 w-100">
							<div class="col-lg-12 pr-0">
								<ul class="nav navbar-nav center_nav pull-right">
									<li class="nav-item active">
										<a class="nav-link" href="/welcome">Home</a>
									</li>
									<li class="nav-item ">
										<a class="nav-link" href="/departments">Departments</a>
									</li>
									<li class="nav-item ">
										<a class="nav-link" href="/doctors">Doctors</a>
									</li>
									<li class="nav-item submenu dropdown">
										<a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Pages</a>
										<ul class="dropdown-menu">
											<li class="nav-item">
												<a class="nav-link" href="/about">About</a>
											</li>
											<li class="nav-item">
												<a class="nav-link" href="/services">Services</a>
											</li>
											<li class="nav-item">
												<a class="nav-link" href="/elements">Elements</a>
											</li>
										</ul>
									</li>
									<li class="nav-item submenu dropdown">
										<a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Blog</a>
										<ul class="dropdown-menu">
											<li class="nav-item">
												<a class="nav-link" href="/blog">Blog</a>
											</li>
											<li class="nav-item">
												<a class="nav-link" href="/single-blog">Blog Details</a>
											</li>
										</ul>
									</li>
									<li class="nav-item">
										<a class="nav-link" href="/contact">Contact</a>
									</li>

									</li>
											<li class ="nav-item">
											<a class="nav-link" href="/logout">Logout</a>
											
										</ul>
									</li>
							</div>
						</div>
					</div>
				</div>
			</nav>
		</div>
	</header>
	<!--================Header Menu Area =================-->
    <!--================ Home Banner Area =================-->
	<!--<section class="home_banner_area">
		<div class="banner_inner d-flex align-items-center">
			<div class="container">
				<div class="banner_content row">
					<div class="col-lg-12">
                    
						<h1>We Care for Your Health Every Moment</h1>
						<p>If you are looking at blank cassettes on the web, you may be very confused at the difference in price You may see some
							for as low as each.</p>
						
					</div>
				</div>
			</div>
		</div>
	</section>-->
	<!--================ End Home Banner Area =================-->



						<!--A Design by W3layouts
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
<title></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Medical Emergency Form template Responsive, Login form web template,Flat Pricing tables,Flat Drop downs Sign up Web Templates, 
 Flat Web Templates, Login sign up Responsive web template, SmartPhone Compatible web template, free web designs for Nokia, Samsung, LG, SonyEricsson, Motorola web design">
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<!-- Custom Theme files -->
<link href="css/style4.css" rel='stylesheet' type='text/css' />
<!--fonts--> 
<link href="//fonts.googleapis.com/css?family=Roboto:300,400,500,700" rel="stylesheet">
<link href="//fonts.googleapis.com/css?family=Droid+Sans:400,700" rel="stylesheet">
<!--//fonts--> 
</head>
<?php
						use App\Register;
                        $sess=session()->get('email');
                        //echo $sess;
                        $a=Register::where('email',$sess)->get();
                        foreach($a as $object) 
                        {
                            //$id=$object->id;
                            $email=$object->email;
                           
                        }   
                       $users=DB::table('registers')->where('email',$sess)->first();
                       
                        ?>
<body>
<!--background-->
<h1> Hospiec</h1>
    <div class="bg-agile">
	<div class="book-appointment">
	<h2>Medical Information</h2>



			<form action="/updatepatientprofile" method="post" enctype="multipart/form-data">
			<div class="form-divider">
         <div class="user-avatar text-center d-block">
       
        <div class="gaps">
						<p><?php echo $users->email; ?></p>
						
	    </div>
				<div class="left-agileits-w3layouts same">
					<div class="gaps">
						<p>Patient Name</p>
						
					<input type="hidden" name="_token" value="{{csrf_token()}}" />
                         <input type="hidden"  name="email" value="<?php echo $users->email;?>">
						 @csrf
						 <input type="text" name="pname" placeholder="" required="" autocomplete="off" value="<?php echo $users->pname; ?>" readonly>
					</div>	
					<div class="gaps">
						<p>Address</p>
							<input type="text" name="address" placeholder="" required="" autocomplete="off" value="<?php echo $users->address; ?>" />
					</div>
					
					
					<!--<div class="gaps">
						<p>State</p>	
						<select class="form-control">
							<option></option>
							<option>State-1</option>
							<option>State-2</option>
							<option>State-3</option>
							<option>State-4</option>
							<option>State-5</option>
						</select>
					</div>
					<div class="gaps">
						<p>Country</p>	
						<select class="form-control">
							<option></option>
							<option>Country-1</option>
							<option>Country-2</option>
							<option>Country-3</option>
							<option>Country-4</option>
							<option>Country-5</option>
						</select>
					</div>-->
					<div class="gaps">
						<p>Gender</p>
							<input type="text" name="gender" placeholder="" required="" autocomplete="off" value="<?php echo $users->gender; ?>" />
					</div>
					<!--<div class="gaps">
						<p>Gender</p>	
							<select class="form-control" value="<?php echo $users->gender; ?>">
								<option></option>
								<option>Male</option>
								<option>Female</option>
							</select>
					</div>-->
					<div class="gaps">
						<p> Date Of Birth</p>		
						<input  id="datepicker1" name="dob" type="text" value="<?php echo $users->dob; ?>"  required="">
						
					</div>
					<!--<div class="gaps">
						<p>Hospital Preference</p>
						<input type="text" name="First Name" placeholder="" required=""/>
					</div>	
					<div class="gaps">
						<p>Insurance Company</p>
						<input type="text" name="First Name" placeholder="" required=""/>
					</div>			
					<div class="gaps">	
						<p>Policy Number</p>
						<input type="text" name="Number" placeholder="" required=""/>
					</div>
					<div class="gaps">
						<p>Physician's Name</p>
						<input type="text" name="First Name" placeholder="" required=""/>
					</div>-->		
					<div class="gaps">	
						<p>Phone Number</p>
						<input type="text" name="phone" placeholder="" required="" autocomplete="off" value="<?php echo $users->phone; ?>" />
					</div>
				</div>
				<div class="right-agileinfo same">
					<div class="gaps">
						<p>Name</p>
						<input type="text" name="name" placeholder="" required="" autocomplete="off" />
					</div>
					<div class="gaps">
						<p>Relationship</p>
						<input type="text" name="relationship" placeholder="" required="" autocomplete="off"/>
					</div>
					<div class="gaps">
						<p>Address</p>
						<textarea id="message" name="address2" placeholder="" title="Please enter Your Comments"></textarea>
						</div>
						<div class="gaps">
						<p>Patient Photo</p>
						<input type="file" id="img" name="photo" class="input-field" />
						</div>
					<!--<div class="gaps">
						<p>City</p>
						<input type="text" name="First Name" placeholder="" required=""/>
					</div>
					
					<div class="gaps">
						<p>State</p>	
						<select class="form-control">
							<option></option>
							<option>State-1</option>
							<option>State-2</option>
							<option>State-3</option>
							<option>State-4</option>
							<option>State-5</option>
						</select>
					</div>
					<div class="gaps">
						<p>Country</p>	
						<select class="form-control">
							<option></option>
							<option>Country-1</option>
							<option>Country-2</option>
							<option>Country-3</option>
							<option>Country-4</option>
							<option>Country-5</option>
						</select>
					</div>
					<div class="gaps">	
						<p>Home Phone</p>
						<input type="text" name="Number" placeholder="" required=""/>
					</div>-->
				</div>
				
				<div class="clear">
				<button type="submit" class="btn btn-primary btn-block">
                      Save
                    </button>
				</div>
				<!--<tr><td><center><p><a href="{{route('editpatientprofile',['email'=>$sess])}}" class="btn btn-action btn-secondary">&nbsp&nbspEdit&nbsp&nbsp</a></td></tr>-->
			</form>
		</div>
   </div>
   
   <!--copyright-->
			<!--<div class="copy w3ls">
		       <p>&copy; 2017. Medical Emergency Form . All Rights Reserved  | Design by <a href="http://w3layouts.com/" target="_blank">W3layouts</a> </p>
	        </div>-->
		<!--//copyright-->
		<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
		<!-- Calendar -->
				<link rel="stylesheet" href="css/jquery-ui.css" />
				<script src="js/jquery-ui.js"></script>
				  <script>
						  $(function() {
							$( "#datepicker,#datepicker1,#datepicker2,#datepicker3" ).datepicker();
						  });
				  </script>
			<!-- //Calendar -->

</body>
</html>
                    