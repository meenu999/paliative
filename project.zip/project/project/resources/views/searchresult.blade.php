<?php
                use App\adddoctor;
				$sess=session()->get('id');
                $sql = DB::select('select * from adddoctors where sid = ?', [$sess]); 
			if(count($sql)!=0)
			{
                foreach($sql as $a)
				{
					$id=$a->id;
					$dname=$a->dname;
					//$surname=$a->surname;
					//$description=$a->description;
					$email=$a->email;
					$phone=$a->phone;
					//$qualification=$a->qualification;
					$photo=$a->photo;
					$sid=$a->sid;
                    $cname=DB::table('specilizations')->select('specilization')->where('sid',$sid)->pluck('specilization');
                }
            }
				?>   