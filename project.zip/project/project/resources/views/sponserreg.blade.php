<!--A Design by W3layouts
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
<title></title>

<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Medical Emergency Form template Responsive, Login form web template,Flat Pricing tables,Flat Drop downs Sign up Web Templates, 
 Flat Web Templates, Login sign up Responsive web template, SmartPhone Compatible web template, free web designs for Nokia, Samsung, LG, SonyEricsson, Motorola web design">
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<!-- Custom Theme files -->
<link href="css/style4.css" rel='stylesheet' type='text/css' />
<!--fonts--> 
<link href="//fonts.googleapis.com/css?family=Roboto:300,400,500,700" rel="stylesheet">
<link href="//fonts.googleapis.com/css?family=Droid+Sans:400,700" rel="stylesheet">
<!-- Adding oh-autoVal css style -->
<link rel="stylesheet" type="text/css" href="css/oh-autoval-style.css">
<!-- Adding jQuery script. It must be before other script files -->
<script src="js/jquery.min.js"> </script>
<!-- Adding oh-autoVal script file -->
<script src="js/oh-autoval-script.js"></script>
<!--//fonts--> 
</head>
<body>
<!--background-->
<h1>Hospice</h1>
    <div class="bg-agile">
	<div class="book-appointment">
	<h2>Registration Form</h2>
	<form  action="/spreg" class="oh-autoval-form" method="post">
		<input type="hidden" name="_token" value="{{csrf_token()}}">	
				<div class="centre-agileits-w3layouts">
					<div class="gaps">
						<p> Name</p>
						<input type="text" name="sname" placeholder="" required="" class="av-name" av-message="Invalid Name" autocomplete="off"/>
					</div>	
					<div class="gaps">
						<p>Address</p>
						<input type="text" name="saddress" placeholder="" title="Please enter Your Comments" class="av-required" av-message="Field is Required" autocomplete="off"></textarea>
						
						</div>
						<div class="gaps">
						<p>District</p>	
                        <input type="text" name="sdistrict" placeholder="" title="Please enter Your Comments" class="av-required" av-message="Field is Required" autocomplete="off"></textarea>
						<!--<select class="form-control" name="district" id="district" onChange="return hi(this.value)" class="av-required" av-message="Field is Required" >
							<option value="0"></option>
							@isset($data)
							@foreach($data as $district)
							<option value="{{$district->district_id}}">{{$district->name}}</option>
							@endforeach
							@endisset
							<option>Kottayam</option>
							<option>Kollam</option>
							<option>State-3</option>
							<option>State-4</option>
							<option>State-5</option>
						</select>-->
					</div>	
			
					<div class="gaps">
						<p>City</p>	
						<input type="text" name="scity" placeholder="" title="Please enter Your Comments" class="av-required" av-message="Field is Required" autocomplete="off"></textarea>
					</div>	
					<div class="gaps">
						<p>Gender</p>	
							<select class="form-control" name="sgender">
								<option></option>
								<option>Male</option>
								<option>Female</option>
								<option>Others</option>
							</select>
					</div>
					<div class="gaps">	
						<p>Phone Number</p>
						<input type="text" name="sphone" placeholder="" required=""  class="av-mobile" av-message="Invalid Mobile Number" autocomplete="off"/>
					</div>
					<?php
						$today=date("12/12/1989");
						?>

				<!--	<div class="gaps">
						<p>Date of Birth</p>		
						<input  id="datepicker1" name="dob" type="text" value="" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'mm/dd/yyyy';}"autocomplete="off" required="" max="<?php echo $today;?>">
					</div>-->
					<div class="gaps">
						<p>User Name</p>
						<input type="email" name="email" placeholder="example@gmail.com" required="" class="av-email" av-message="Invalid email address" autocomplete="off"/>
					</div>
				
					<div class="gaps">
						<p>Password</p>
						<input type="password" name="password" placeholder=""id="password" required ="" class="av-password" av-message="Password must contain uppercase,lowercase,special chars,digits and minimum 6 chars." autocomplete="off" />
					</div>			
					<div class="gaps">	
						<p>Confirm Password</p>
						<input type="password" name="cpassword" placeholder="" id="confirm_password" required onchange='check();' class="av-password" av-message="Password must contain uppercase,lowercase,special chars,digits and minimum 6 chars." autocomplete="off" onkeyup='check();'/>
					</div>
					
				</div>
			

				<!--<div class="right-agileinfo same">
					<div class="gaps">
						<p>Name</p>
						<input type="text" name="First Name" placeholder="" required=""/>
					</div>
					<div class="gaps">
						<p>Relationship</p>
						<input type="text" name="First Name" placeholder="" required=""/>
					</div>
					<div class="gaps">
						<p>Address</p>
						<textarea id="message" name="message" placeholder="" title="Please enter Your Comments"></textarea>
						</div>
					<div class="gaps">
						<p>City</p>
						<input type="text" name="First Name" placeholder="" required=""/>
					</div>
					
					<div class="gaps">
						<p>State</p>	
						<select class="form-control">
							<option></option>
							<option>State-1</option>
							<option>State-2</option>
							<option>State-3</option>
							<option>State-4</option>
							<option>State-5</option>
						</select>
					</div>
					<div class="gaps">
						<p>Country</p>	
						<select class="form-control">
							<option></option>
							<option>Country-1</option>
							<option>Country-2</option>
							<option>Country-3</option>
							<option>Country-4</option>
							<option>Country-5</option>
						</select>
					</div>
					<div class="gaps">	
						<p>Home Phone</p>
						<input type="text" name="Number" placeholder="" required=""/>
					</div>-->
				</div>
				
				<div class="clear"></div>
				<input type="submit" name="submitt" value="Register">
			</form>
		</div>
   </div>
   <script>
							function hi(id)
							{
								$.ajaxSetup({
									headers: {
										'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
									}
								});
								var distID = id;
								
								
									
									$.ajax({
										url: '/show_city',
										type: "POST",
										data: {did : distID},
										
										success:function(data) 
										{
											

											$('#city').empty();
											for(var i=0;i<data.length;i++){
											$('#city').append('<option value="'+ data[0].id +'">'+ data[0].city_name +'</option>');
											}


										}
									});
								
								   
							}
							</script>

</body>
<!-- Jquery JS-->
	
    <script src="{{asset('js/jquery-3.3.1.js')}}">
	script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
		<!-- Calendar -->
				<link rel="stylesheet" href="css/jquery-ui.css" />
				<script src="js/jquery-ui.js"></script>
				  <script>
						  $(function() {
							$( "#datepicker,#datepicker1,#datepicker2,#datepicker3" ).datepicker();
						  });
	</script>
</html>
<!-- end document-->

   <!--copyright-->
			<div class="copy w3ls">
		       
	        </div>
		<!--//copyright-->
		<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
		<!-- Calendar -->
				<link rel="stylesheet" href="css/jquery-ui.css" />
				<script src="js/jquery-ui.js"></script>
				  <script>
						  $(function() {
							$( "#datepicker,#datepicker1,#datepicker2,#datepicker3" ).datepicker();
						  });
				  </script>
			<!-- //Calendar -->


</body>
</html>