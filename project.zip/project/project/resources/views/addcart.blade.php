<!doctype html>
<html lang="en">

<head>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="icon" href="img/favicon.png" type="image/png">
	<title>Hospice Medical</title>
    
	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="css/bootstrap.css">
	<link rel="stylesheet" href="vendors/linericon/style.css">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="vendors/owl-carousel/owl.carousel.min.css">
	<link rel="stylesheet" href="vendors/lightbox/simpleLightbox.css">
	<link rel="stylesheet" href="vendors/nice-select/css/nice-select.css">
	<link rel="stylesheet" href="vendors/animate-css/animate.css">
	<link rel="stylesheet" href="vendors/jquery-ui/jquery-ui.css">
	<!-- main css -->
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/responsive.css">
	<style>
.example1 {
 height: 50px;	
 overflow: hidden;
 position: relative;
}
.example1 h3 {
 font-size: 3em;
 color: limegreen;
 position: absolute;
 width: 100%;
 height: 100%;
 margin: 0;
 line-height: 50px;
 text-align: center;
 /* Starting position */
 -moz-transform:translateX(100%);
 -webkit-transform:translateX(100%);	
 transform:translateX(100%);
 /* Apply animation to this element */	
 -moz-animation: example1 15s linear infinite;
 -webkit-animation: example1 15s linear infinite;
 animation: example1 15s linear infinite;
}
/* Move it (define the animation) */
@-moz-keyframes example1 {
 0%   { -moz-transform: translateX(100%); }
 100% { -moz-transform: translateX(-100%); }
}
@-webkit-keyframes example1 {
 0%   { -webkit-transform: translateX(100%); }
 100% { -webkit-transform: translateX(-100%); }
}
@keyframes example1 {
 0%   { 
 -moz-transform: translateX(100%); /* Firefox bug fix */
 -webkit-transform: translateX(100%); /* Firefox bug fix */
 transform: translateX(100%); 		
 }
 100% { 
 -moz-transform: translateX(-100%); /* Firefox bug fix */
 -webkit-transform: translateX(-100%); /* Firefox bug fix */
 transform: translateX(-100%); 
 }
}
</style>

</head>

<body>



	<!--================Header Menu Area =================-->
	<header class="header_area">
		<div class="top_menu row m0">
			<div class="container">
            <div style="width:500px;margin-left:1000px;margin-top:20px;">
            Welcome   {{Session::get('email')}}
           {{csrf_field() }}
		  </div> 
				<!--<div class="float-left">
					<ul class="left_side">
						<li>
							<a href="login.html">
								<i class="fa fa-facebook-f"></i>
							</a>
						</li>
						<li>
							<a href="login.html">
								<i class="fa fa-twitter"></i>
							</a>
						</li>
						<li>
							<a href="login.html">
								<i class="fa fa-dribbble"></i>
							</a>
						</li>
						<li>-->
						
							
						</li>
					</ul>
				</div>
				<!--<div class="float-right">
					<ul class="right_side">
						<li>
							<a href="login.html">
								<i class="lnr lnr-phone-handset"></i>
								6532-568-9746
							</a>
						</li>
						<li>
							<a href="#">
								<i class="lnr lnr-envelope"></i>
								emergency@hospicegmail.com
							</a>
						</li>
					</ul>
				</div>-->
				<marquee behavior="scroll" direction="left"><h3>Free Medical aids</h3></marquee>
				
			</div>
		</div>
		<div class="main_menu">
			<nav class="navbar navbar-expand-lg navbar-light">
				<div class="container">
					<!-- Brand and toggle get grouped for better mobile display -->
					<a class="navbar-brand logo_h" href="index.html">
						<img src="img/logo.png" alt="">
					</a>
					<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
					 aria-expanded="false" aria-label="Toggle navigation">
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<!-- Collect the nav links, forms, and other content for toggling -->
					<div class="collapse navbar-collapse offset" id="navbarSupportedContent">
						<div class="row ml-0 w-100">
							<div class="col-lg-12 pr-0">
								<ul class="nav navbar-nav center_nav pull-right">
									<li class="nav-item active">
										<a class="nav-link" href="/patienthome">Home</a>
									</li>
									<li class="nav-item ">
										<a class="nav-link" href="/departments">Departments</a>
									</li>
									<li class="nav-item ">
										<a class="nav-link" href="/doctors">Doctors</a>
									</li>
									<!--<li class="nav-item submenu dropdown">
										<a href="/addcart" class="nav-link dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Medicines</a>
										<!--<ul class="dropdown-menu">
											<li class="nav-item">
												<a class="nav-link" href="/about">About</a>
											</li>
											<li class="nav-item">
												<a class="nav-link" href="/services">Services</a>
											</li>
											
										</ul>
									</li>-->
									<li class="nav-item submenu dropdown">
										<a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Profile</a>
										<ul class="dropdown-menu">
											<li class="nav-item">
												<a class="nav-link" href="/patientprofile">Edit Profile</a>
											</li>
											<li class="nav-item">
												<a class="nav-link" href="/updatepatientprofile">View Profile</a>
											</li>
										</ul>
									</li>
									<!--<li class="nav-item">
										<a class="nav-link" href="/patientprofile">Profile</a>
										<ul class="dropdown-menu">
											<li class="nav-item">
												<a class="nav-link" href="/about">About</a>
											</li>
											</ul>
									</li>-->

									</li>
											<li class ="nav-item">
											<a class="nav-link" href="/logout">Logout</a>
											
										</ul>
									</li>
							</div>
						</div>
					</div>
				</div>
			</nav>
			</div>
			
		
	<div class="container products">

 
        <div class="row">
		<?php

                          use App\Product;
                           $sql=DB::select('SELECT * FROM products');
						   
                           foreach($sql as $user)
                           {
                              //$status=$user->status;
                               //$id=$user->id;
						      
                     ?>       
 
            <div class="col-xs-18 col-sm-6 col-md-3">
                <div class="thumbnail">
				
                    
					<img src="../../../../storage/upload/<?php echo $user->image;?>"  width="200" height="300">
                    <div class="caption">
                        <h4>Product Name:<?php echo $user->name;?></h4>
                        <p>Description:<?php echo $user->description;?></p>
                        <p><strong>Quantity: </strong><?php echo $user->count;?> </p>
						
						<form action="/cart" method="post">
						@csrf
						<input type="hidden" name="pid" value="<?php echo $user->pid;?>">			
                       <!--<input type="submit" class="btn btn-warning btn-block text-center" role="button">Add to cart</a> </p>-->
                       <input type="submit" class="btn btn-warning btn-block text-center" name="submit" value="Add to cart">
				  </form>
				   </div>
                </div>
            </div>
			     <?php
			}
			?>
 
	



	<!--================ Optional JavaScript =================-->
	<!--================ jQuery first, then Popper.js, then Bootstrap JS =================-->
	
	<script src="js/jquery-3.2.1.min.js"></script>
	<script src="js/popper.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="vendors/nice-select/js/jquery.nice-select.min.js"></script>
	<script src="vendors/isotope/isotope-min.js"></script>
	<script src="vendors/owl-carousel/owl.carousel.min.js"></script>
	<script src="js/jquery.ajaxchimp.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/Counter-Up/1.0.0/jquery.counterup.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/waypoints/4.0.1/jquery.waypoints.min.js"></script>
	<script src="js/mail-script.js"></script>
	<script src="js/custom.js"></script>
</body>

</html>

