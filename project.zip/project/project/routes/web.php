<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('/welcome', function () {
    return view('welcome');
});
Route::get('/doctors', function () {
    return view('doctors');
});
Route::get('/appointment', function () {
    return view('appointment');
});
Route::get('/about', function () {
    return view('about');
});
Route::get('/departments', function () {
    return view('departments');
});
Route::get('/product', function () {
    return view('product');
});
Route::get('/viewproduct', function () {
    return view('viewproduct');
});


Route::get('/services', function () {
    return view('services');
});
Route::get('/contact', function () {
    return view('contact');
});
Route::get('/blog', function () {
    return view('blog');
});
Route::get('/single-blog', function () {
    return view('single-blog');
});
Route::get('/Meenu', function () {
    return view('Meenu');
});
Route::get('/index', function () {
    return view('index');
});
Route::get('/doctorreg', function () {
    return view('doctorreg');
});
Route::get('/adddoctor', function () {
    return view('adddoctor');
});
Route::get('/viewdoctor', function () {
    return view('viewdoctor');
});

Route::get('/profile', function () {
    return view('profile');
});
Route::get('/myaccount', function () {
    return view('profile');
});
Route::get('/viewleave', function () {
    return view('viewleave');
});
Route::get('/patientprofile', function () {
    return view('patientprofile');
});

Route::get('/patienthome', function () {
    return view('patienthome');
});
Route::get('/patienthomenew', function () {
    return view('patienthomenew');
});


Route::get('/forget', function () {
    return view('forget');
});
Route::get('/dash', function () {
    return view('dash');
});
Route::get('/addspecilization', function () {
    return view('addspecilization');
});
Route::get('/editdoctorprofile',function() {
	return view('editdoctorprofile');
  
});

Route::get('/leave',function() {
	return view('leave');
  
});
Route::get('/viewcart',function() {
	return view('viewcart');
  
});
Route::get('/layout',function() {
	return view('layout');
  
});
Route::get('/addcart',function() {
	return view('addcart');
  
});
Route::get('/payment',function() {
	return view('payment');
  
});
Route::get('/sponserhome',function() {
	return view('sponserhome');
  
});
Route::get('/makepayment',function() {
	return view('makepayment');
  
});
Route::get('/sponserreg',function() {
    	return view('sponserreg');
      
    });
Route::get('/print',function() {
    	return view('print');
      
 });
 Route::get('/charity',function() {
    return view('charity');
  
});
Route::get('/viewdoctorleave',function() {
    return view('viewdoctorleave');
  
});
Route::get('/doctorhome',function() {
    return view('doctorhome');
  
});

Route::get('/viewappointments', function () {
    return view('viewappointments');
});   
Route::get('/viewdoctorappointments', function () {
    return view('viewdoctorappointments');
});
Route::get('/addcamps', function () {
    return view('addcamps');
});
Route::get('/viewcamp', function () {
    return view('viewcamp');
});
Route::get('/Medical Camp', function () {
    return view('Medical Camp');
});
Route::get('/pviewcamp', function () {
    return view('pviewcamp');
});
Route::get('/addtreatment', function () {
    return view('addtreatment');
});
Route::get('/feedback', function () {
    return view('feedback');
});
Route::get('/viewtreatment', function () {
    return view('viewtreatment');
});





Auth::routes();
Route::any('/index','DistrictController@index');

Route::get('/home', 'HomeController@index')->name('home');
Route::get('/Login', 'LoginController@index')->name('home');
Route::post('/loginn', 'LoginController@login')->name('home');
Route::post('/register', 'RegisterController@register')->name('home');
Route::post('/reg', 'RegisterController@store')->name('home');
Route::post('/spreg', 'sponserController@store')->name('home');
Route::post('/reg', 'RegisterController@store')->name('home');
Route::post('/reg', 'RegisterController@store')->name('home');
Route::post('/adddoctor', 'AdddoctorController@adddoctor')->name('home');
Route::post('/adddoc','AdddoctorController@store')->name('home');
Route::get('/viewdoctor', 'AdddoctorController@index');
Route::get('/viewproduct', 'ProductController@index');
Route::any('/cart','CartController@addcart');

Route::get('delete/{id}', 'AdddoctorController@destroy');
Route::get('delete1/{campid}', 'CampsController@destroy');
Route::get('editdoctorprofile/{email}','AdddoctorController@edit');
Route::get('/editdoctorprofile/{email}','AdddoctorController@update');
Route::get('/updatepatientprofile','RegisterController@update');
Route::post('/leave', 'LeaveController@insert');
Route::post('/addproduct', 'ProductController@insert');
Route::get('delete/{pid}', 'CartController@destroy');
Route::post('/feedback','FeedbackController@store');


Route::post('/show_city','DistrictController@cityajax');
Route::any('/logout','\App\Http\Controllers\Auth\LoginController@logout');
Route::get('/profile/{username}',[
    'as' => 'docs', 'uses' => 'AdddoctorController@profile'
]);

Route::get('/leave/{id}',['as'=>'status','uses'=>'LeaveController@update']);

Route::get('/patientprofile/{username}',[
    'as' => 'logs', 'uses' => 'RegisterController@profile'
]);
Route::post('/addspecilization','SpecilizationController@insert');
Route::get('/amount','AmountController@insert');
Route::post('/payment','PaymentController@insert');

    
Route::get('/editdoctorprofile/{email}',[
   'as'=>'editdoctorprofile','uses'=>'AdddoctorController@edit']);
Route::post('/updatedoctorprofile','AdddoctorController@update');

Route::get('/editpatientprofile/{email}',[
    'as'=>'editpatientprofile','uses'=>'RegisterController@edit']);
Route::post('/updatepatientprofile','RegisterController@update');
 
Route::post('/appointment','AppointmentsController@appointment');
Route::post('/addcamp','CampsController@store');
Route::post('/addtreatment','TreatmentController@store');






//Route::resource('/register', 'RegisterController')->name('home');




Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
