<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAdddoctorsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('adddoctors', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('dname');
            $table->string('sid');
            $table->string('address');
            $table->string('country');
            $table->string('state');
            $table->string('city');
            $table->string('email');
            $table->string('gender');
            $table->string('phone');
            $table->string('photo');
            $table->string('experience');
            $table->string('proof');
			$table->string('username');
			$table->string('password');
			$table->string('role');
			$table->string('status');
            $table->timestamps();
			
        });
    }


    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('adddoctors');
    }
}
