<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateRegistersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('registers', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('pname');
            $table->string('address');
            $table->string('district');
            $table->string('city');
            $table->string('gender');
            $table->string('phone');
			$table->string('dob');
            $table->string('email');
            $table->string('name');
            $table->string('relationship');
            $table->string('address2');
			$table->string('role');
			$table->string('status');
			
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('registers');
    }
}
