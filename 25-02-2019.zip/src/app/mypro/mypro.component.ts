import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mypro',
  templateUrl: './mypro.component.html',
  styleUrls: ['./mypro.component.css']
})
export class MyproComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
