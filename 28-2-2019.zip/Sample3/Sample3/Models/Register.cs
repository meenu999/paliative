﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Sample3.Models
{
    public class Register
    {
        [Required(ErrorMessage="Can't be Empty")]
        [Display(Name="Student Name")]
        public string Name { get; set; }

        [Required(ErrorMessage="Can't be Empty")]
        [Display(Name="Student Address")]
        [DataType(DataType.MultilineText)]
        public string Address { get; set; }
        [Required(ErrorMessage = "Can't be Empty")]
        [Display(Name = "Student Gender")]
        public string Gender { get; set; }
        [ Required(ErrorMessage="Can't be Empty")]
        [Display(Name="Course")]
        public  course courselist{ get;set; }
        [ Required(ErrorMessage="Can't be Empty")]
        [Display(Name="Student Email")]
        [DataType(DataType.EmailAddress)]
        public string Email{get;set;}

        [ Required(ErrorMessage="Can't be Empty")]
        [Display(Name="Username")]
        public string Username{get;set;}
        [ Required(ErrorMessage="Can't be Empty")]
        [Display(Name="Password")]
        [DataType(DataType.Password)]
        public string Password{get;set;}
        [ Required(ErrorMessage="Can't be Empty")]
        [Display(Name="Confirm Password")]
        [DataType(DataType.Password)]
        public string confirmpassword{get;set;}
        [StringLength(30)]
        [Display(Name = "Image")]
        public string PostImage { get; set; }
        [Display(Name = "Terms and Conditions")]
        [Range(typeof(bool), "true", "true", ErrorMessage = "You gotta tick the box!")]
        public bool TermsAndConditions { get; set; }	
           
   } 
    public enum course
    {
        MCA,BCA,BCom
       
    }

}   

  
