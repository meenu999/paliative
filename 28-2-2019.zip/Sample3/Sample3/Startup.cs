﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(Sample3.Startup))]
namespace Sample3
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
