<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::get('/form', function () {
    return view('form');
});

Route::get('/Home', function () {
    return view('welcome');
});


Route::get('/Home/{id}', function ($id) {
    return 'hai My id is'.$id;
});

Route::get('/Haii', function () {
    return view('laravels.about');
});	

Route::get('/create', function () {
    return view('notes.note');
});	
Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
Route::get('/index', 'LaravelsController@index');
Route::get('/about', 'LaravelsController@about');
Route::get('/services', 'LaravelsController@services');
Route::get('/sample','NotesController@sample');
Route::resource('/notes','NotesController');

