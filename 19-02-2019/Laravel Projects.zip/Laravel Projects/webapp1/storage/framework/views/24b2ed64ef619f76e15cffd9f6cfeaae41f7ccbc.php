<form method="post" action="<?php echo e(route('notes.store')); ?>">
<?php echo csrf_field(); ?>
Title<input type= "text" name="Title"><br/>
Body<input type="text" name="Body">
<input type="submit" name="submit" value="ADD"></br>
</form>