<form method="post" action="">
Title<input type= "text" name="Title"><br/>
Body<input type="text" name="Body">
<input type="button" name="submitt" value="ADD">
</form>