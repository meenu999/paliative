<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class notes extends Model
{
	
	public $fillable=[
	'title','body','author','price',];
    //
}
