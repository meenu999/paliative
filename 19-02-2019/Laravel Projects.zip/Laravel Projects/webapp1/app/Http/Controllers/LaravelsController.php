<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class LaravelsController extends Controller
{
	public function about()
	{
		
	   return view('laravels.about');
	}
     public function index()
	 {
		 $title="MEENU THOMAS";
		//return view('laravels.index',compact('title'));
		return view('laravels.index')->with('name',$title);
	 }	
	 public function Services()
	 {
		return view('laravels.services'); 
	 }	
    //
}
