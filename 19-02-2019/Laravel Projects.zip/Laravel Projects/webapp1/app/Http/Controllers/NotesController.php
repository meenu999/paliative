<?php

namespace App\Http\Controllers;

use App\notes;
use Illuminate\Http\Request;

class NotesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
		return view('notes.note');
        //
    }
	
	
	public function sample()
    {
		return view('welcome');
        //
    }
	

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
		$notes= new notes([
		'title'=>$request->get('Title'),
		'body'=>$request->get('Body'),
		'author'=>$request->get('Author'),
		'rate'=>$request->get('Rate')
		]);
        //
		$notes->save();
		return redirect('/notes/create');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\notes  $notes
     * @return \Illuminate\Http\Response
     */
    public function show(notes $notes)
    {
		//return view('notes.note');
        //
		return "haiiii";
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\notes  $notes
     * @return \Illuminate\Http\Response
     */
    public function edit(notes $notes)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\notes  $notes
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, notes $notes)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\notes  $notes
     * @return \Illuminate\Http\Response
     */
    public function destroy(notes $notes)
    {
        //
    }
}
