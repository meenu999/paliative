@extends('layouts.app1')
  @section('content')
<h1>Index</h1>
<h2>{{$name}}</h2>
<p>Haii All</p>
@endsection