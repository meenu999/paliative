﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace database.Models
{
    public class Customer
    {
        public int CustomerId{get;set;}
        [Required(ErrorMessage="Can,t be Empty")]
        [Display(Name="Customer Name")]
        public string cname{get;set;}
        [Required(ErrorMessage="Can,t be Empty")]
        [Display(Name="Customer Address")]
        
        public string caddress{get;set;}
        [Required(ErrorMessage="Can,t be Empty")]
        [Display(Name="Customer Email")]
        public string cemail{get;set;}
        [Required(ErrorMessage="Can,t be Empty")]
        [Display(Name="Customer Username")]
        public string cusername{get;set;}
[Required(ErrorMessage="Can,t be Empty")]
        [Display(Name="Customer Password")]
        public string cpassword{get;set;}

    }
}