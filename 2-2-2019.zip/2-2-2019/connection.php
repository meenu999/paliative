<?php
	
	$con=mysqli_connect("localhost","root","","angulardb");
	if($con)
	{
		//echo"success";
	}
	else
	{
		echo"not success";
	}

header("Acess-Control-Allow-Origin:  *");
header("Acess-Control-Allow-Method: PUT,GET,POST");
header("Acess-Control-Allow-Headers:Origins,X-Requested-With,Content-Type-Acess");
$postdata=file_get_contents("php://input");
$request=json_decode($postdata);
$name=mysqli_real_escape_string($con,trim($request->data->name));
$ussername=mysqli_real_escape_string($con,trim($request->data->username));
$password=mysqli_real_escape_string($con,trim($request->data->password));
$status=mysqli_real_escape_string($con,trim($request->data->status));
$sql="insert into reg (name,username,password,status)values('$name','$username','$pasword',1)";
if(mysqli_query($con,$sql)){
	http_response_code(201);
	$student=['name'=>$name,'username'=>$username,'password'
=>$password	,'status'=>$status,'id'=>mysqli_insert_id($con)];
echo json_encode(['data'=>$student]);
}
?>
