export class student{
    id:number;name:string;
    username:string;
    constructor(
        

        
    ){
        
    }
}
