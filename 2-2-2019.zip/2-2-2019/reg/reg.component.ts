import { Component, OnInit } from '@angular/core';
import{student}from '../student';
import { from } from 'rxjs';
import {NgForm} from '@angular/forms';
import { DemoService } from '../demo.service';

@Component({
  selector: 'app-reg',
  templateUrl: './reg.component.html',
  styleUrls: ['./reg.component.css']
})
export class RegComponent implements OnInit {
student = new student();
isreg=false;
  constructor( private regservice:DemoService ) { }
 
  ngOnInit() {}
    reg(f: NgForm){
      this.regservice.store(this.student).subscribe(data=>{
        this.isreg=true;
        console.log("registered sucessfully");
        f.reset();
      },
      (err)=>{
      this.isreg=false});
    
  }
}
