import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProfileComponent } from './profile/profile.component';
import { DemoComponent } from 'src/1_2_2019/demo/demo.component';
import { logging } from 'protractor';

const routes: Routes = [{path:"home",component:ProfileComponent},{path:"about",component:DemoComponent}];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
